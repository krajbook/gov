<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();	
	
		$this->load->library('form_validation');

		$this->load->library('pagination');
		
		$this->load->model('nlp_model');
	}

	
	public function index()
	{
	   $this->data['title'] = 'Home';
	   	
       $this->load->view('web/index',$this->data);
	 }

	public function project()
	{
	   $this->data['title'] = 'Project';
	   $this->load->view('web/project');
	}

	public function contact()
	{
	   $this->data['title'] = 'Contact';		
       $this->load->view('web/contact');
	  
	}

	
	public function district()
	{
	   $this->data['title'] = 'State District';
       
       $id = $this->uri->segment(3);
       $category = $this->nlp_model->select('category',array('id !='=>'7'))->result_array();
      
       $product_data = $this->nlp_model->select('district',array('name'=>$id))->row_array();
       if($product_data>0 )
       {
           $project_data = $this->nlp_model->select('products',array('district_name'=>$product_data['id']))->result_array();
         
           $this->data['district'] = $id;
           $this->data['product_data'] = $product_data;
           $this->data['project_data'] = $project_data;
           $this->data['category'] = $category;
    	   $this->load->view('web/district', $this->data);
    	  	  
       }else{
       $this->data['district'] = $id;
       $this->data['product_data'] = array();
       $this->data['project_data'] = array();
	   $this->data['category'] = $category;
       $this->load->view('web/district', $this->data);
       }
	}


    

	public function report()
	{
	   $id = $this->uri->segment(3);
       $summary = $this->nlp_model->select('products',array('id'=>$id))->row_array();
       $this->data['summary'] = $summary;
	   $this->data['title'] = 'Report';
	   $this->load->view('web/report',$this->data);
	}


	public function category()
	{
	   $cat_id = $this->uri->segment(3);
	   $dist_id = $this->uri->segment(4);
	   
	   $this->data['title'] = 'Category';		
       
       $cat_data = $this->nlp_model->select('products',array('district_name'=>$dist_id,'category_id'=>$cat_id))->result_array();
       $c = $this->nlp_model->select('category',array('id'=>$cat_id))->row_array();
      
       $d = $this->nlp_model->select('district',array('id'=>$dist_id))->row_array();
         
       $this->data['cat_id'] = $c;
       $this->data['dist_id'] = $d;
       $this->data['cat_data'] = $cat_data;
           
	   $this->load->view('web/category',$this->data);
	}

	public function appoinment_ajax()
	{
		$name = $this->input->post('name');
		$mobile = $this->input->post('mobile');
		$message = $this->input->post('message');
		$email = $this->input->post('email');
		$subject = $this->input->post('subject');

		$data = array(
             
             'name' => $name,
             'mobile' => $mobile,
             'email' => $email,
             'subject' => $subject,
             'message' => $message,
		);

		$create = $this->nlp_model->insert('appoinment',$data);

		if($create == 1)
		{
			echo "Success !";
		}
		else{
			echo "Try again";
		}
	}


	public function login()
	{

		// $this->logged_in();

		$this->form_validation->set_rules('mobile', 'Mobile', 'required');

        if ($this->form_validation->run() == TRUE) {
            // true case
           	$mobile_exists = $this->nlp_model->check_mobile($this->input->post('mobile'));

           	if($mobile_exists == TRUE) {
           		$login = $this->nlp_model->login($this->input->post('mobile'));

           		if($login) {

           			$logged_in_sess = array(
           				'id' => $login['id'],
				        'username'  => $login['full_name'],
				        'email'     => $login['email'],
				        'logged_in' => TRUE
					);

					$this->session->set_userdata($logged_in_sess);
           			redirect('auth', 'refresh');
           		}
           		else {
           			$this->data['errors'] = 'Incorrect Mobile Number';
           			$this->load->view('web/index', $this->data);
           		}
           	}
           	else {
           		$this->data['errors'] = 'Email does not exists';

           		$this->load->view('web/index', $this->data);
           	}	
        }
        else {
            // false case
            $this->load->view('web/index');
        }	
	}


	public function website_terms_and_conditions()
	{
		$this->data['privacy'] = 'Privacy';
        // $this->load->view('templates/header', $this->data);
	    $this->load->view('web/website-terms-and-conditions',$this->data);
	    $this->load->view('templates/footer', $this->data);
	   	
	}

	/*
		clears the session and redirects to login page
	*/
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('web/login', 'refresh');
	}

}

?>