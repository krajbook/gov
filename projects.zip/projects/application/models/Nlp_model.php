<?php if (!defined('BASEPATH')) exit('No direct script access allowed');



class nlp_model extends CI_Model

{ 

	function __construct()

	{

		 parent::__construct();

		 $this->load->helper('url');

	}

	
	function insert($table,$data) #INSERT

	{

	if($this->db->insert($table,$data))

	return true;

	else

	return false;

	}

	
	function select($table,$cond='',$cond1='',$in='',$infield='') #SELECT

	{

	$this->db->select('*');

	$this->db->from($table);

	if($cond!='')

	{

	$this->db->where($cond);

	}
	
	if($cond1!='')

	{

	$this->db->where($cond1);

	}

	if($in!=''&&$infield!='')

	{

	$this->db->where_in($infield,$in);

	}


	$query = $this->db->get();

	return $query;	

	}
    
    public function get_count_all($table) 
    {
        return $this->db->count_all($table);
    }

    public function get_products($limit, $start,$table) 
    {
        $this->db->limit($limit, $start);

        $query = $this->db->get($table);
 
        return $query;
    }

	function select_order($table,$cond='',$order_id='',$order_order='',$in='',$infield='') #SELECT
	{

		$this->db->select('*');

		$this->db->from($table);

		if($cond!='')

		{

		$this->db->where($cond);

		}

		if($order_id !='' && $order_order !='')

		{

			$this->db->order_by($order_id,$order_order);

		}

	

		if($in!=''&&$infield!='')

		{

		$this->db->where_in($infield,$in);

		}

		$query = $this->db->get();

		return $query;	

	}



	function delete($table,$cond) #DELETE

	{

	if($this->db->delete($table,$cond))

	return true;

	else

	return false;

	}

	

	function update($table,$data,$cond) #UPDATE

	{

	if($this->db->update($table,$data,$cond))

	return true;

	else

	return false;

	}


	function ajax_select($table,$cond='') #SELECT

	{

	$this->db->select('*');

	$this->db->from($table);

	if($cond!='')

	{

	$this->db->where($cond);

	}

	$query = $this->db->get();
   
	return $query->row();	

	}
	
    public function check_mobile($mobile) 
	{
		if($mobile) {
			$sql = 'SELECT * FROM users WHERE mobile = ? AND status = 1';
			$query = $this->db->query($sql, array($mobile));
			$result = $query->num_rows();
			return ($result == 1) ? true : false;
		}

		return false;
	}

	/* 
		This function checks if the email and password matches with the database
	*/
	public function login($mobile) 
	{
		if($mobile) 
		{
			$sql = "SELECT * FROM users WHERE mobile = ? AND status = 1";
			$query = $this->db->query($sql, array($mobile));

			if($query->num_rows() == 1) 
			{
				$result = $query->row_array();

				if($result === true) 
				{
					return $result;	
				}
				else {
					return false;
				}

				
			}
			else {
				return false;
			}
		}
	}
}