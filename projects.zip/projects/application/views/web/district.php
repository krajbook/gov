<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Youth Empowerment</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link href="<?php echo base_url('styles.css') ?>" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="size">
  <div class="header">
    <div class="header01">
      <div class="logo"> <img src="<?php echo base_url('image/log.png') ?>" height="80px" width="450px" alt="" /> </div>
      <div class="hright">
        <div class="hr01">
          <div class="hr0101"> <a href="https://chillkrt.com/youth-emp/admin" target="_blank">Login to youth empowerment</a></div>
          <div class="hr0102"> <a href="https://chillkrt.com/youth-emp/admin" target="_blank">Login to Head Office</a></div>
        </div>
        <div class="hr02">
          <input id="Text1" type="text" value="Search..." />
        </div>
      </div>
    </div>
    <div class="mnav">
      <div class="mnm">
        <ul>
          <li><a href="<?php echo base_url('web'); ?>">HOME</a></li>
          <li><a href="<?php echo base_url('web/project'); ?>">PROJECT</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="content">    
     <div class="submenu" style="left: 0px; top: 0px">
      <div class="subtext"> You are here:district </div>
      <div class="subimag" style="width: 41px; height: 51px">
        <ul>
          <li>1</li>
          <li>2</li>
          <li>3</li>
        </ul>
      </div>
    </div>
    <?php if($product_data){ ?>
    <div class="row" style="padding-bottom:50px;">
         <div class="mcleft">
            <img src="<?php echo base_url($product_data['image']) ?>" style="height:30vh; width:30vh">
        </div>
        <div class="mc0201"> Category lists</div>
         <div class="mcright">
             
            <ul>
                <?php foreach($category as $cat){ ?>
                <li style="font-size:22px"><a href="<?php echo base_url('web/category/') ?><?php echo $cat['id'] ?>/<?php echo $product_data['id'] ?>"><?php echo $cat['name'] ?></a></li>
                <?php } ?>
            </ul>
          
    <?php }else{?>
    <p>No project</p>
    <?php } ?>
  </div>
  <div class="row">
               &nbsp;&nbsp;
  </div><br><br><br><br><br>
  <div class="footer"> <a href="<?php echo base_url('web')?>">HOME</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo base_url('web/project')?>">PROJECT</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo base_url('web/contact')?>">CONTACT</a> <br/>
    <font color="#333333">Copyright 2021 Youth Empowerment </font></div>
</div>
<div align=center>All rights reserver by <a href='#'>Youth Empowerment</a></div></body>
</html>
