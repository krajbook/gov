<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Youth Empowerment</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link href="<?php echo base_url('styles.css') ?>" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="size">
  <div class="header">
    <div class="header01">
      <div class="logo"> <img src="<?php echo base_url('image/log.png') ?>" height="80px" width="450px" alt="" /> </div>
      <div class="hright">
        <div class="hr01">
          <div class="hr0101"> <a href="https://chillkrt.com/youth-emp/admin" target="_blank">Login to youth empowerment</a></div>
          <div class="hr0102"> <a href="https://chillkrt.com/youth-emp/admin" target="_blank">Login to Head Office</a></div>
        </div>
        <div class="hr02">
          <input id="Text1" type="text" value="Search..." />
        </div>
      </div>
    </div>
    <div class="mnav">
      <div class="mnm">
        <ul>
          <li><a href="<?php echo base_url('web'); ?>">HOME</a></li>
          <li><a href="<?php echo base_url('web/project'); ?>">PROJECT</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="content">
    <div class="submenu" style="left: 0px; top: 0px">
      <div class="subtext"> You are here:Home </div>
      <div class="subimag" style="width: 41px; height: 51px">
        <ul>
          <li>1</li>
          <li>2</li>
          <li>3</li>
        </ul>
      </div>
    </div>
    <div class="mcontent">
      <div class="mcleft">
        <div class="mcbox01">
          <div class="mc01t"> MAIN MENU </div>
          <div class="mc01c">
            <ul>
              <li><a href="<?php echo base_url('web')?>">Home</a></li>
              <li><a href="<?php echo base_url('web/project')?>">Project</a></li>
            </ul>
          </div>
          <div class="mc01b"> <img src="<?php echo base_url('image/img_272.jpg')?>" alt="" /> </div>
        </div>
        <div class="mcbox01">
          <div class="mc01t2"> LATEST NEWS </div>
          <div class="mc01cc">
            <ul>
              <li><a href="#">Hostel</a></li>
              <li><a href="#">Stadium</a></li>
              <li><a href="#">Projects</a></li>
              <li><a href="#">Maintanence</a></li>
              <li><a href="#">Vision</a></li>
              <li><a href="#">Mission</a></li>
            </ul>
          </div>
          <div class="mc01b"> <img src="<?php echo base_url('image/img_272.jpg')?>" alt="" /> </div>
        </div>
        <div class="mcbox01">
          <div class="mc01t2"> LINKS </div>
          <div class="mc01cc">
            <ul>
              <li><a href="#">E-governance</a></li>
              <li><a href="#">Quality</a></li>
              <li><a href="#">Going green</a></li>
              <li><a href="#">Event</a></li>
              <li><a href="#">Corporate Social Responsibility</a></li>
              <li><a href="#">E-point book</a></li>
            </ul>
          </div>
          <div class="mc01b"> <img src="<?php echo base_url('image/img_272.jpg')?>" alt="" /> 
          </div>
        </div>
      </div>
      <div class="mcright">
        <div class="mc01">
          <div class="mc0101" style="left: 0px; top: 0px"> 
            <div class="mcr">
              <div class="mcr01"> Introduction </div>
              <div class="mcr02"> Infrastructure sector is a key driver for the Indian economy. Infrastructure sector includes power, bridges, dams, roads, ect. urban infrastructure development. </div>
            </div>
          </div>
          <div class="mc0102">
            <div class="mcl">
              <div class="mcl01"> Reports </div>
              <div class="mcl02"> Increased impetus to develop infrastructure in the country is attracting both domestic and international players. </div>
            </div>
          </div>
        </div>
        <div class="mc02">
          <div class="mc0201"> Welcome to Youth empowerment </div>
          <div class="mc0202" style="width: 18px; height: 15px"> &nbsp; </div>
          <div class="mc0203">
            <div class="mc020301">
              <p>Infrastructure sector is a key driver for the Indian economy. The sector is highly responsible for propelling India’s overall development and enjoys intense focus from Government for initiating policies that would ensure time-bound creation of world class infrastructure in the country. Infrastructure sector includes power, bridges, dams, roads, and urban infrastructure development.</p>  
              <p>According to the Department for Promotion of Industry and Internal Trade (DPIIT), FDIs in the construction development sector (townships, housing, built up infrastructure and construction development projects) and construction (infrastructure) activities stood at US$ 25.93 billion and US$ 23.99 billion, respectively, between April 2000 and December 2020. In FY21, infrastructure activities accounted for 13% share of the total FDI inflows of US$ 81.72 billion.</p>
            </div>
            <div class="mc020302">
              <ul>
              <li><a href="#">E-governance</a></li>
              <li><a href="#">Quality</a></li>
              <li><a href="#">Going green</a></li>
              <li><a href="#">Event</a></li>
              <li><a href="#">Corporate Social Responsibility</a></li>
              <li><a href="#">E-point book</a></li>
              </ul>
            </div>
            <div class="mc020303">
             <p>Increased impetus to develop infrastructure in the country is attracting both domestic and international players. Private sector is emerging as a key player across various infrastructure segments, ranging from roads and communications to power and airports. In order to boost the construction of buildings in the country, the Government of India has decided to come up with a single window clearance facility to accord speedy approval of construction projects.</p> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer"> <a href="<?php echo base_url('web')?>">HOME</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo base_url('web/project')?>">PROJECT</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo base_url('web/contact')?>">CONTACT</a> <br/>
    <font color="#333333">Copyright 2021 Youth Empowerment </font></div>
</div>
<div align=center>All rights reserver by <a href='#'>Youth Empowerment</a></div></body>
</html>
  