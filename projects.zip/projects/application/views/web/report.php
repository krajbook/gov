<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1"><title>
</title>
	<script src="Scripts/jquery-1.4.1.min.js" type="text/javascript"></script>
    <style type="text/css">
	.CSSTableGenerator {
	margin:0px;padding:0px;
	width:100%;
	box-shadow: 10px 10px 5px #888888;
	border:1px solid #000000;
	
	-moz-border-radius-bottomleft:0px;
	-webkit-border-bottom-left-radius:0px;
	border-bottom-left-radius:0px;
	
	-moz-border-radius-bottomright:0px;
	-webkit-border-bottom-right-radius:0px;
	border-bottom-right-radius:0px;
	
	-moz-border-radius-topright:0px;
	-webkit-border-top-right-radius:0px;
	border-top-right-radius:0px;
	
	-moz-border-radius-topleft:0px;
	-webkit-border-top-left-radius:0px;
	border-top-left-radius:0px;
}.CSSTableGenerator table{
    border-collapse: collapse;
        border-spacing: 0;
	width:100%;
	height:100%;
	margin:0px;padding:0px;
}.CSSTableGenerator tr:last-child td:last-child {
	-moz-border-radius-bottomright:0px;
	-webkit-border-bottom-right-radius:0px;
	border-bottom-right-radius:0px;
}
.CSSTableGenerator table tr:first-child td:first-child {
	-moz-border-radius-topleft:0px;
	-webkit-border-top-left-radius:0px;
	border-top-left-radius:0px;
}
.CSSTableGenerator table tr:first-child td:last-child {
	-moz-border-radius-topright:0px;
	-webkit-border-top-right-radius:0px;
	border-top-right-radius:0px;
}.CSSTableGenerator tr:last-child td:first-child{
	-moz-border-radius-bottomleft:0px;
	-webkit-border-bottom-left-radius:0px;
	border-bottom-left-radius:0px;
}.CSSTableGenerator tr:hover td{
	
}
.CSSTableGenerator tr:nth-child(odd){ background-color:#e5e5e5; }
.CSSTableGenerator tr:nth-child(even)    { background-color:#ffffff; }.CSSTableGenerator td{
	vertical-align:middle;
	
	background-color:#cccccc;
	border:1px solid #000000;
	border-width:0px 1px 1px 0px;
	text-align:left;
	padding:7px;
	font-size:14px;
	font-family:Arial;
	font-weight:normal;
	color:#000000;
}.CSSTableGenerator tr:last-child td{
	border-width:0px 1px 0px 0px;
}.CSSTableGenerator tr td:last-child{
	border-width:0px 0px 1px 0px;
}.CSSTableGenerator tr:last-child td:last-child{
	border-width:0px 0px 0px 0px;
}
.CSSTableGenerator tr:first-child td{
		background:-o-linear-gradient(bottom, #cccccc 5%, #b2b2b2 100%);	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #cccccc), color-stop(1, #b2b2b2) );
	background:-moz-linear-gradient( center top, #cccccc 5%, #b2b2b2 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#cccccc", endColorstr="#b2b2b2");	background: -o-linear-gradient(top,#cccccc,b2b2b2);

	background-color:#cccccc;
	border:0px solid #000000;
	text-align:center;
	border-width:0px 0px 1px 1px;
	font-size:14px;
	font-family:Arial;
	font-weight:bold;
	color:#000000;
}
.CSSTableGenerator tr:first-child:hover td{
	background:-o-linear-gradient(bottom, #cccccc 5%, #b2b2b2 100%);	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #cccccc), color-stop(1, #b2b2b2) );
	background:-moz-linear-gradient( center top, #cccccc 5%, #b2b2b2 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#cccccc", endColorstr="#b2b2b2");	background: -o-linear-gradient(top,#cccccc,b2b2b2);

	background-color:#cccccc;
}
.CSSTableGenerator tr:first-child td:first-child{
	border-width:0px 0px 1px 0px;
}
.CSSTableGenerator tr:first-child td:last-child{
	border-width:0px 0px 1px 1px;
}
	 .logos a,.logos a img
 {
     max-height: 100%;
     display: block;
     width:100px;
     height:200px;
 }

 .logos a:hover img
 {
     border: solid 12px black;
     position: fixed;
     right: 10px; 
     top: 10px; 
     z-index:10;
 }
			
	.thumbnail:hover {
    position:relative;
    top:-40px;
    left:0px;
    width:600px;
    height:auto;
    display:block;
    z-index:999;
}
	
        .button
        {
            border: solid 1px #c0c0c0;
            background-color: #D55500;
            color: #ffffff;
            cursor: pointer;
            font-weight: bold;
        }
		.loader
        {
            position: fixed;
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background: url('<?php echo base_url("image/page-loader.gif")?> 50% 50% no-repeat rgb(249,249,249);
        }
    
        .zoom_img img {
            margin: 20px;
            height: 100px;
            width: 100px;
            -moz-transition: -moz-transform 0.5s ease-in;
            -webkit-transition: -webkit-transform 0.5s ease-in;
            -o-transition: -o-transform 0.5s ease-in;
        }

            .zoom_img img:hover {
                -moz-transform: scale(2);
                -webkit-transform: scale(2);
                -o-transform: scale(2);
            }

            .fillwidth {
    width: auto;
    height: auto;
}
            
        .auto-style1 {
            height: 88px;
        }

      
            
    </style>
     
    <script type="text/javascript">
        $(function () {
            $("img.imgthumb").click(function (e) {
                var newImg = '<img src='
                                + $(this).attr("src") + '></img>';
                $('#ladiv')
                    .html($(newImg)
                    .animate({ height: '300', width: '450' }, 1500));
            });
        });    
     </script>
    <link href="Css/styles.css" rel="stylesheet" type="text/css" />
    <link href="Styles/modern.css" rel="stylesheet" type="text/css" />
    <link href="Styles/dropdown.css" rel="stylesheet" type="text/css" />
    <link href="Styles/Grid.css" rel="stylesheet" type="text/css" /></head>
<body>

    <form name="form1" method="post" action="#" id="form1">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUJNzU3MzIxMzU0D2QWAgIDD2QWAgIFD2QWLgIDDw8WAh4EVGV4dAVBQkFOR0FMT1JFIFJJQ0hNT05EIFJPQUQgIEtTUlAgMVNUIEJBVFRBTElPTiBBUk1PVVJZIFdJVEggTUFHQVpJTkVkZAILDw8WBB8ABSNDb250cmFjdG9yLVZlZXJhc3dhbXlyZWRkeSBhbmQgU29ucx4LUG9zdEJhY2tVcmwFF0NvbnRyYWN0b3JOYW1lUGFnZS5hc3B4ZGQCDQ9kFgJmD2QWAgIBDzwrAA8BAA8WBh4NRW1wdHlEYXRhVGV4dAUVTk8gUGljdHVyZXMgQXZhaWxhYmxlHgtfIURhdGFCb3VuZGceC18hSXRlbUNvdW50AilkFgJmD2QWCGYPDxYCHgdWaXNpYmxlaGRkAgEPZBYCAgEPZBYCAgEPDxYCHwAFUjIyLTA3LTIwMTYmbmJzcDxici8+PGJyLz5EZXNjcmlwdGlvbjombmJzcDsmbmJzcDtPdXRzaWRlIGZsYWdnaW5nPGJyLz5QaWM6IDEgb2YgNDFkZAICD2QWAgIBD2QWBGYPDxYEHghJbWFnZVVybAVnfi9VcGxvYWRlZEZpbGVzL0xpdmVQcm9qZWN0L3s4ZWYwYTQ2MC1hZDJkLTRjODAtYWFjNC1mY2U1YTQ1YWIzZDF9L1BpY3R1cmUvV1BfMjAxNjA3MTlfMTZfMzBfNDFfUHJvLmpwZx4NQWx0ZXJuYXRlVGV4dGVkZAIBDw8WAh8FaGRkAgMPDxYCHwVoZGQCEw8PFgIfAAUHQUUyQk5HMmRkAhcPDxYCHwAFCzEyNTAwMDAwLjAwZGQCGw8PFgIfAAUrUEhDL0NvbnRyYWN0cy9JUkEvMjAxNS0xNi8yMSBEdDogMTYtMDctMjAxNWRkAh8PDxYCHwAFHURDLU1PLzAxL0JORyhVLTEpMjAxNC0xNS83ODM1ZGQCIw8PFgIfAAULMjQgU2VwIDIwMTVkZAInDw8WAh8ABQsyNSBKdWwgMjAxNmRkAisPDxYCHwAFCzI0IFNlcCAyMDE1ZGQCLw8PFgIfAAULMjYgSnVsIDIwMTZkZAIzDw8WAh8ABQsxMDI5NTQyMS4wMGRkAjcPDxYCHwAFCzEwODk1NDIxLjAwZGQCOw8PFgIfAAUJQ29tcGxldGVkZGQCPw8PFgIfAAUXMCB5ZWFyIDEwIG1vbnRocyA1IGRheXNkZAJDDw8WAh8ABQ9CQU5HQUxPUkUgVVJCQU5kZAJHDw8WAh8ABQczNTAwLjAwZGQCSw8PFgIfAAUkQ29tcGxldGlvbiBvZiBIYW5kaW5nIG92ZXIgdG8gcG9saWNlZGQCTw8PFgIfAAUXMCB5ZWFyIDEwIG1vbnRocyA2IGRheXNkZAJRDw8WAh8FaGRkAl0PDxYCHwAFCzEyNjM5MjYyLjUzZGQCXw8PFgIfBWhkZAJpDxYCHwVoFgICAQ9kFgJmD2QWAgIED2QWBgIBDw8WAh8ABQsxMjUwMDAwMC4wMGRkAgMPDxYCHwAFCzEwMjk1NDIxLjAwZGQCBQ8PFgIfAAULMTI2MzkyNjIuNTNkZBgCBR5fX0NvbnRyb2xzUmVxdWlyZVBvc3RCYWNrS2V5X18WBgUIaW1ncHJpbnQFB2ltZ21haWwFCWltZ3RvcnJlZAUMSW1hZ2VCdXR0b24zBQlpbWdjc3RyZWQFDEltYWdlQnV0dG9uMgUMRGV0YWlsc1ZpZXcxDxQrAAdkZGRkZBYAAilk0mUyujNUHvWrOt3HCHeUV/bwnX0=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
if (typeof(Sys) === 'undefined') throw new Error('ASP.NET Ajax client-side framework failed to load.');
//]]>
</script>

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="B03CA3CE" />
	<input type="hidden" name="__PREVIOUSPAGE" id="__PREVIOUSPAGE" value="4RINgCBmFLRE7h15o9UkDOYaIYaNpgNoJ4DbTSsH9e4Gbq8NRZASSfHLy6752r9rIOMu1R66ZtoEKNBRKJWZceFHTTMklzDL5E1q0sjj2umz1Tdd0" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEWCgLH5fPLDwKunOjlBQLnybiYBgL4ucWfBgLl5YmEBALxwMLmAQKQz8TjBALSwsGJCgLU0fjsCgLSwtXkAnbAna4b+JlPx3fw+lfmtvyYGD2v" />
</div>
    <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('scr', document.getElementById('form1'));
Sys.WebForms.PageRequestManager.getInstance()._updateControls(['tup1'], [], [], 90);
//]]>
</script>

    <div id="div1"  >
     

                    
        <div id="Panel1">
	
            <table id="tblcloseoropen" style="margin-left:5px" width="100%">
		<tr>
			<td class="auto-style1" align="center">
                        <img src="<?php echo base_url('image/log.png')?>" width="40%" height="80px"/>
                    </td>
		</tr>
		<tr>
			<td style="width:100%" colspan="2" align="center">
                        <span id="lbltxt2" style="color:#0066FF;font-family:Arial;font-size:Large;">PROJECT SUMMARY</span>
                    </td>
		</tr>
	</table>
	
            <table style="margin-left:5px"  width="100%">
                <tr>
                                <td  align="center" width="80%" colspan="3" >
                                    <span id="lblprojidget" style="color:Blue;font-family:Khmer UI;font-size:X-Large;font-weight:bold;"><?php print_r($summary['name']); ?></span>
                                    <input type="image" name="imgprint" id="imgprint" src="<?php echo base_url('image/printer_icon.jpg')?>" onclick="Javascript: window.print();" style="border-width:0px;" />
                                    <input type="image" name="imgmail" id="imgmail" src="<?php echo base_url('image/email_icon.jpg')?>" style="border-width:0px;" />
                                </td>
                            </tr>
                  
                <tr>
                    <td style="margin-left:5px" colspan="3"  width="90%">
                        <table class="CSSTableGenerator" style="border: thin solid #999999;width:100%">
                            <tr>
							 <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblcntrctname" style="font-size:Medium;">Contractor Name</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <a id="lnkcntrctnametxt" style="font-size:Medium;"><?php print_r($summary['contractor_name']) ?></a>
                                </td>
                               
                                <td align="center" colspan="3" rowspan="16" style="border: thin solid #999999;width:50%" nowrap="nowrap" >
                                    <div id="up1">
		
                                            <div>
			<table cellspacing="0" rules="all" pagesize="1" border="1" id="DetailsView1" style="border-collapse:collapse;">
				<tr>
					<td>&nbsp;</td><td>                                                     
                      <b style="color:Blue;">Uploaded:&nbsp;&nbsp;</b>
                      <span id="DetailsView1_lblimgtxt" style="color:Blue;"><?php print_r($summary['created_at']) ?>&nbsp;<br/><br/>Description:&nbsp;&nbsp;<?php print_r($summary['description']) ?><br/></span>
                    </td>
				</tr><tr>
					<td>&nbsp;</td><td class=" zoom_img">
					    <?php 
                                               $files = json_decode($summary['image'],true);
                                               if(count($files)>0)
												{  
													foreach ($files as $files_name) 
													{?>
					    <img src="https://chillkrt.com/youth-emp/admin/<?php echo $files_name; ?>" style="height:30vh;width:30vh"/>
					    <?php } } ?>
					    </td>
				</tr>
			</table>
		</div>
                                    
	</div>
                                    <br />
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblpm" style="font-size:Medium;">Project Manager</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblpmtxt" style="font-size:Medium;"><?php $m_name = $this->nlp_model->select('users',array('id'=>$summary['project_manager']))->row_array();
                   print_r($m_name['username']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblestcost" style="font-size:Medium;">Estimate Cost In Rs.</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblestcosttxt" style="font-size:Medium;"><?php print_r($summary['contract_amount']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblagno" style="font-size:Medium;">Agreement Number</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblagnotxt" style="font-size:Medium;"><?php print_r($summary['agreement_number']) ?></span>
                                </td>
                            </tr>
                            <tr>
                               
							    <td class="style11" style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblprojname" style="font-size:Medium;">Work Indent Number</span>
                                </td>
                                <td class="style9" style="border: thin solid #999999;width:50%" >
                                    <span id="lblprojcodetxt" style="font-size:Medium;"><?php print_r($summary['id']) ?></span>
                                </td>
							   
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblschsrtdt" style="font-size:Medium;">Scheduled Start Date</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblschsrtdttxt" style="font-size:Medium;"><?php print_r($summary['scheduled_start_date']) ?></span>
                                </td>
                            </tr>
                     <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblschendt" style="font-size:Medium;">Scheduled End Date</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblschendttxt"><?php print_r($summary['scheduled_end_date']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblactstdt" style="font-size:Medium;">Actual Start Date</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblactstdttxt" style="font-size:Medium;"><?php print_r($summary['actual_start_date']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblactendt" style="font-size:Medium;">Actual End Date</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblactendttxt" style="font-size:Medium;"><?php print_r($summary['actual_end_date']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lbltendamt" style="font-size:Medium;">Amount Put To Tender</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lbltendamttxt" style="font-size:Medium;"><?php print_r($summary['amount_put_to_tender']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblcntctamt" style="font-size:Medium;">Contract Amount In Rs.</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblcntctamttxt" style="font-size:Medium;"><?php print_r($summary['contract_amount']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblprojstat" style="font-size:Medium;">Project Status</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblprojstattxt" style="font-size:Medium;"><?php print_r($summary['status']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblcntctper" style="font-size:Medium;">Contract Period</span>
                                </td>
                                <td style="border: thin solid #999999;width:40%" >
                                    <span id="lblcntctpertxt" style="font-size:Medium;"><?php print_r($summary['contract_period']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lbldistname">District Name	</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%">
                                    <span id="lbldistnametxt" style="font-size:Medium;"><?php $dt = $this->nlp_model->select('district',array('id'=>$summary['district_name']))->row_array(); print_r($dt['name']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="Labelblplarea" style="font-size:Medium;">Plinth Area(Sqm)</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblplareatxt" style="font-size:Medium;"><?php print_r($summary['plinth_area_sq']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblstatus" style="font-size:Medium;">Year</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%">
                                    <span id="lblstatustxt" style="font-size:Medium;"><?php $yr = $this->nlp_model->select('year',array('id'=>$summary['year']))->row_array(); print_r($yr['year']) ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lblactexecper" style="font-size:Medium;">Actual Execution Period</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lblactexecpertxt" style="font-size:Medium;"><?php print_r($summary['actual_execution_period']) ?></span>
                                </td>
                                <td style="border: thin solid #000000;width:20%;font-weight:bold" >
                                    
                                    <input type="image" name="imgtorred" id="imgtorred" src="<?php echo base_url('image/redtor.jpg')?>" style="border-width:0px;" />
                                    <span id="lbltortxt"><?php print_r($summary['id']) ?></span>
                                </td>
                                <td style="border: thin solid #000000;width:20%" >
                                    <input type="image" name="ImageButton3" id="ImageButton3" src="<?php echo base_url('image/QualityDetails.png')?>" style="border-width:0px;" />
                                </td>
                                <td style="border: thin solid #000000;width:18%">
                                    <img id="Image5" src="<?php echo base_url('image/Normal.png')?>" style="border-width:0px;" />
                                </td>
                            </tr>
                            <tr>
                                <td style="border: thin solid #999999;width:15%" nowrap="nowrap">
                                    <span id="lbluptodtexp" style="font-size:Medium;">Upto Date Expenditure</span>
                                </td>
                                <td style="border: thin solid #999999;width:50%" >
                                    <span id="lbluptodtexptxt" style="font-size:Medium;"><?php print_r($summary['upto_date_expenditure']) ?></span>
                                </td>
                                <td style="border: thin solid #000000;width:20%;font-weight:bold">
                                    &nbsp;
                                    
                                    <input type="image" name="imgcstred" id="imgcstred" src="<?php echo base_url('image/redtor.jpg')?>" style="border-width:0px;" />
                                    <span id="lblcortxt"><?php print_r($summary['id']) ?></span>
                                </td>
                                <td style="border: thin solid #000000;width:20%;font-weight:bold" >
                                    &nbsp;
                                    <input type="image" name="ImageButton2" id="ImageButton2" src="<?php echo base_url('image/OtherIssues.png')?>" style="border-width:0px;" />
                                </td>
                                <td style="border: thin solid #000000;width:20%;font-weight:bold">
                                    &nbsp;
                                    <img id="Image8" src="<?php echo base_url('image/OverRun.png')?>" style="border-width:0px;" />
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class="customerName" colspan="3">
                        
                    </td>
                </tr>
            </table>
        
</div>
     
    </div>
    

<script type="text/javascript">
//<![CDATA[
Sys.Application.initialize();
//]]>
</script>
</form>
</body>
<script type="text/javascript">
    $(window).load(function () {
        $(".loader").fadeOut("slow");
    })
</script>
</html>

