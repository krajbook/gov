<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require(APPPATH.'/libraries/REST_Controller.php');

use Restserver\Libraries\REST_Controller;

    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Content-Type: multipart/form-data; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,  X-Requested-With");
    

class Api extends REST_Controller
{
       public function __construct() 
       {
               parent::__construct();
       
               $this->load->model('model_users');
               $this->load->model('model_products');
               $this->load->model('model_category');
               $this->load->model('model_auth');
       }    

        public function user_get()
       {
           
           $r = $this->model_users->select('users',array('id <>'=>'1'))->result_array();
           $this->response($r); 
          
       }

    public function register_post() 
    {
            $this->load->library('upload');
            $files = $_FILES;
                     
                $_FILES['product_image']['name']= $files['product_image']['name'];
                $_FILES['product_image']['type']= $files['product_image']['type'];
                $_FILES['product_image']['tmp_name']= $files['product_image']['tmp_name'];
                $_FILES['product_image']['error']= $files['product_image']['error'];
                $_FILES['product_image']['size']= $files['product_image']['size'];    
                $type = explode('.', $_FILES['product_image']['name']);
                    
                $this->upload->initialize($this->set_upload_options());
                $this->upload->do_upload('product_image');
                $dataInfo = trim('assets/images/product_image/'.$this->upload->file_name);
            
              
            $password = $this->password_hash($this->post('password'));
            $upload_image = $dataInfo;
            $data = array(
                'username' => $this->post('username'),
                'password' => $password,
                'map' => $upload_image,
                'email' => $this->post('email'),
                'firstname' => $this->post('fname'),
                'lastname' => $this->post('lname'),
                'phone' => $this->post('phone'),
                'gender' => $this->post('gender'),
                'status' => 1,
                'role' => $this->post('role'),
                'designation' => $this->post('designation'),
                'district' => $this->post('district_id'),
                'created_at' => date('Y-m-d h:i a')
            );

            $register = $this->model_users->create($data,$this->post('role'));
            if($register == true)
            {
                   // Set the response and exit
                    $this->response([
                        'status' => TRUE,
                        'message' => 'User Create successful.',
                        ], REST_Controller::HTTP_OK);
                            
            }else{
                           $this->response([
                                    'status' => FALSE,
                                    'message' => 'Invalid Parameter'
                                ],REST_Controller::HTTP_BAD_REQUEST); 
           }     
       
    }

      public function login_post() 
      {
        $body = file_get_contents('php://input');
        $object = json_decode($body);
          
        if ($object->email != '' || $object->password != '') 
        {
          
            // true case
            $email_exists = $this->model_auth->check_email($object->email);
          
            if($email_exists !='')
            {
               
                if($email_exists == TRUE) 
                {
                    $login = $this->model_auth->login($object->email, $object->password);
     
                    if($login) 
                    {
                     
                   // Set the response and exit
                    $this->response([
                        'status' => TRUE,
                        'message' => 'User login successful.',
                        'data' => $login
                    ], REST_Controller::HTTP_OK);
                    }else{
                         $this->response([
                        'status' => FALSE,
                        'message' => 'Invalid Password'
                    ],REST_Controller::HTTP_BAD_REQUEST);
                    }
                }
            }else{
                     
                    $this->response([
                        'status' => FALSE,
                        'message' => 'Invalid Email or Password'
                    ],REST_Controller::HTTP_BAD_REQUEST);
                }
        }else{
            
            // Set the response and exit
            $this->response([
                        'status' => FALSE,
                        'message' => 'Provide Correct Details'
                    ], REST_Controller::HTTP_BAD_REQUEST);
        }
        
    }
    
    public function password_hash($password = '')
    {
        if($password) {
            $password = password_hash($password, PASSWORD_DEFAULT);
            return $password;
        }
    }
    
    public function district_get()
    {
           $r = $this->model_users->select('district')->result_array();
           $this->response($r); 
        
    }

    public function taluk_get()
    {
           $r = $this->model_users->select('taluk')->result_array();
           $this->response($r); 
        
    }


    public function category_get()
    {
           $r = $this->model_users->select('category')->result_array();
           $this->response($r); 
        
    }
   
    
    public function year_get()
    {
        $r = $this->model_users->select('year')->result_array();
        $this->response($r);
    }

    public function workById_post()
    {
        $body = file_get_contents('php://input');
        $object = json_decode($body);
          
        $taluk_id = $object->taluk_id;
        $year_id = $object->year_id;
        $id = $object->category_id;
        if($id)
        {
            if($id =='7'){
            $r = $this->model_users->select('products',array('category_id'=>$id,'year'=>$year_id,'taluk_name'=>$taluk_id))->result_array();
            }else{
             $r = $this->model_users->select('products',array('category_id'=>$id))->result_array();    
            }
            $this->response([
                        'status' => TRUE,
                        'data' => $r,
                    ], REST_Controller::HTTP_OK);
        
        }else{
            $this->response([
                        'status' => FALSE,
                        'message' => 'Provide Category Id',
                    ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
   

    public function work_post()
    { 
         if($this->post('product_name') != '')
         {
                  
            $this->load->library('upload');

            $dataInfo = array();
            $files = $_FILES;
            $cpt = count($_FILES['product_image']['name']);
                
            for($i=0; $i<$cpt; $i++)
            {           
                $_FILES['product_image']['name']= $files['product_image']['name'][$i];
                $_FILES['product_image']['type']= $files['product_image']['type'][$i];
                $_FILES['product_image']['tmp_name']= $files['product_image']['tmp_name'][$i];
                $_FILES['product_image']['error']= $files['product_image']['error'][$i];
                $_FILES['product_image']['size']= $files['product_image']['size'][$i];    
                $type = explode('.', $_FILES['product_image']['name']);
                $type = $type[count($type) - 1];
                    
                $this->upload->initialize($this->upload_files());
                $this->upload->do_upload('product_image');
                $dataInfo[] = trim('assets/images/product_image/'.$this->upload->file_name);
                
            }
            $im = json_encode($dataInfo);          
            
            $this->load->library('upload');
            $files_m = $_FILES;
                     
                $_FILES['product_file']['name']= $files_m['product_file']['name'];
                $_FILES['product_file']['type']= $files_m['product_file']['type'];
                $_FILES['product_file']['tmp_name']= $files_m['product_file']['tmp_name'];
                $_FILES['product_file']['error']= $files_m['product_file']['error'];
                $_FILES['product_file']['size']= $files_m['product_file']['size'];    
                $type = explode('.', $_FILES['product_file']['name']);
                    
                $this->upload->initialize($this->upload_file());
                $this->upload->do_upload('product_file');
                $maintain = trim('assets/images/product_image/'.$this->upload->file_name);
            
            $main =  $maintain;       
    
    
            $this->load->library('upload');
            $main_infra_file = $_FILES;
                     
                $_FILES['infrastructure_details_file']['name']= $main_infra_file['infrastructure_details_file']['name'];
                $_FILES['infrastructure_details_file']['type']= $main_infra_file['infrastructure_details_file']['type'];
                $_FILES['infrastructure_details_file']['tmp_name']= $main_infra_file['infrastructure_details_file']['tmp_name'];
                $_FILES['infrastructure_details_file']['error']= $main_infra_file['infrastructure_details_file']['error'];
                $_FILES['infrastructure_details_file']['size']= $main_infra_file['infrastructure_details_file']['size'];    
                $type = explode('.', $_FILES['infrastructure_details_file']['name']);
                    
                $this->upload->initialize($this->set_upload_options());
                $this->upload->do_upload('infrastructure_details_file');
                $main_infra = trim('assets/images/product_image/'.$this->upload->file_name);
            
            $main_infra_details = $main_infra;
            
            $data = array(
                'name' => $this->post('product_name'),
                'image' => $upload_image,
                'maintanance_file' => $main,
                'infrastructure_details_file' => $main_infra_details,
                'description' => $this->post('description'),
                'category_id' => $this->post('category_id'),
                'contractor_name' => $this->post('contractor_name'), 
                'project_manager' => $this->post('project_manager'),
                'agreement_number' => $this->post('agreement_number'),   
                'scheduled_start_date' => date('Y-m-d',$this->post('scheduled_start_date')),   
                'scheduled_end_date' => date('Y-m-d',$this->post('scheduled_end_date')),
                'actual_start_date' => date('Y-m-d',$this->post('actual_start_date')),
                'actual_end_date' => date('Y-m-d',$this->post('actual_end_date')),
                'amount_put_to_tender' => $this->post('amount_put_to_tender'),
                'contract_amount' => $this->post('contract_amount'),
                'status' => $this->post('status'),
                'fund_released' => $this->post('fund_released'),
                'expenditure' => date('Y-m-d',$this->post('expenditure')),
                'year' => $this->post('year_id'),
                'contract_period' => $this->post('contract_period'),
                'district_name' => $this->input->post('district_id'),  
                'taluk_name' => $this->input->post('taluk_id'),  
                'plinth_area_sq' => $this->post('plinth_area_sq'),
                'actual_execution_period' => $this->post('actual_execution_period'),
                'active' => '1',
                'created_at' => date('Y-m-d h:i')
            );
            
            $create = $this->model_products->create($data);

                    if($create) 
                    {
                     
                  // Set the response and exit
                    $this->response([
                        'status' => TRUE,
                        'message' => 'Work Created Successfully',
                        
                    ], REST_Controller::HTTP_OK);
                    }else{
                         $this->response([
                        'status' => FALSE,
                        'message' => 'Invalid Parameter or Request'
                    ],REST_Controller::HTTP_BAD_REQUEST);
                    }
        }else{
            $this->response([
                        'status' => FALSE,
                        'message' => 'Invalid Parameter or Request'
                    ],REST_Controller::HTTP_BAD_REQUEST);
        }

    }
   
    private function upload_files()
    {
        $config = array(
            'upload_path'   => 'assets/images/product_image',
            'file_name'     => $_FILES['product_image']['name'],
            'allowed_types' => 'jpg|gif|png|jpeg',
            'max_size'      => 2000,
            'overwrite'     => 1,                       
        );

        return $config;
    }
  
    public function workupdate_post()
    { 
         if($this->uri->segment(3) != '')
         {
            $id = $this->uri->segment(3);        
            $this->load->library('upload');
            $dataInfo = array();
            $files = $_FILES;
            $cpt = count($_FILES['product_image']['name']);
                
            for($i=0; $i<$cpt; $i++)
            {           
                $_FILES['product_image']['name']= $files['product_image']['name'][$i];
                $_FILES['product_image']['type']= $files['product_image']['type'][$i];
                $_FILES['product_image']['tmp_name']= $files['product_image']['tmp_name'][$i];
                $_FILES['product_image']['error']= $files['product_image']['error'][$i];
                $_FILES['product_image']['size']= $files['product_image']['size'][$i];    
                $type = explode('.', $_FILES['product_image']['name']);
                $type = $type[count($type) - 1];
                    
                $this->upload->initialize($this->set_upload_options());
                $this->upload->do_upload('product_image');
                $dataInfo[] = trim('assets/images/product_image/'.$this->upload->file_name);
                
            }
            
            $update_image = json_encode($dataInfo);
            if($update_image !='' && $id !='')
            {
               $upload_image = $update_image;        
            }else{
              $select = $this->model_users->select('products',array('id'=>$id))->row_array();
              
              $upload_image = $select['image'];
            }
            
            $this->load->library('upload');
            $files_m = $_FILES;
                     
                $_FILES['product_file']['name']= $files_m['product_file']['name'];
                $_FILES['product_file']['type']= $files_m['product_file']['type'];
                $_FILES['product_file']['tmp_name']= $files_m['product_file']['tmp_name'];
                $_FILES['product_file']['error']= $files_m['product_file']['error'];
                $_FILES['product_file']['size']= $files_m['product_file']['size'];    
                $type = explode('.', $_FILES['product_file']['name']);
                    
                $this->upload->initialize($this->upload_file());
                $this->upload->do_upload('product_file');
                $maintain = trim('assets/images/product_image/'.$this->upload->file_name);
            
            $maintain_file =  $maintain;       
            if($maintain_file !='' && $id !='')
            {
               $main = $maintain_file;        
            }else{
              $select = $this->model_users->select('products',array('id'=>$id))->row_array();
              
              $main = $select['maintanance_file'];
            }
            
            $this->load->library('upload');
            $main_infrast_file = $_FILES;
                     
                $_FILES['infrastructure_details_file']['name']= $main_infrast_file['infrastructure_details_file']['name'];
                $_FILES['infrastructure_details_file']['type']= $main_infrast_file['infrastructure_details_file']['type'];
                $_FILES['infrastructure_details_file']['tmp_name']= $main_infrast_file['infrastructure_details_file']['tmp_name'];
                $_FILES['infrastructure_details_file']['error']= $main_infrast_file['infrastructure_details_file']['error'];
                $_FILES['infrastructure_details_file']['size']= $main_infrast_file['infrastructure_details_file']['size'];    
                $type = explode('.', $_FILES['infrastructure_details_file']['name']);
                    
                $this->upload->initialize($this->upload_file());
                $this->upload->do_upload('infrastructure_details_file');
                $infrast = trim('assets/images/product_image/'.$this->upload->file_name);
            
            $infrast_file =  $infrast;       
            if($infrast_file !='' && $id !='')
            {
               $xl_file = $infrast_file;        
            }else{
              $select = $this->model_users->select('products',array('id'=>$id))->row_array();
              
              $xl_file = $select['infrastructure_details_file'];
            }
            
            $data = array(
                'name' => $this->post('product_name'),
                'image' => $upload_image,
                'maintanance_file' => $main,
                'infrastructure_details_file' => $xl_file,
                'description' => $this->post('description'),
                'category_id' => $this->post('category_id'),
                'contractor_name' => $this->post('contractor_name'), 
                'project_manager' => $this->post('project_manager'),
                'agreement_number' => $this->post('agreement_number'),   
                'scheduled_start_date' => date('Y-m-d',$this->post('scheduled_start_date')),   
                'scheduled_end_date' => date('Y-m-d',$this->post('scheduled_end_date')),
                'actual_start_date' => date('Y-m-d',$this->post('actual_start_date')),
                'actual_end_date' => date('Y-m-d',$this->post('actual_end_date')),
                'amount_put_to_tender' => $this->post('amount_put_to_tender'),
                'contract_amount' => $this->post('contract_amount'),
                'fund_released' => $this->post('fund_released'),
                'expenditure' => date('Y-m-d',$this->post('expenditure')),
                'status' => $this->post('status'), 
                'year' => $this->post('year_id'),
                'contract_period' => $this->post('contract_period'),
                'district_name' => $this->input->post('district_id'),  
                'taluk_name' => $this->input->post('taluk_id'),  
                'plinth_area_sq' => $this->post('plinth_area_sq'),
                'actual_execution_period' => $this->post('actual_execution_period'),
                'active' => '1',
                'created_at' => date('Y-m-d h:i')
            );
            
            $work_update = $this->model_users->update('products',$data,array('id'=>$id));

                    if($work_update == true) 
                    {
                     
                  // Set the response and exit
                    $this->response([
                        'status' => TRUE,
                        'message' => 'Work Updated Successfully',
                        
                    ], REST_Controller::HTTP_OK);
                    }else{
                         $this->response([
                        'status' => FALSE,
                        'message' => 'Invalid Id'
                    ],REST_Controller::HTTP_BAD_REQUEST);
                    }
        }else{
            $this->response([
                        'status' => FALSE,
                        'message' => 'Invalid Parameter or Request'
                    ],REST_Controller::HTTP_BAD_REQUEST);
        }

    }
   
    
    public function maintanence_post() 
    {
            $this->load->library('upload');
            $files = $_FILES;
                     
                $_FILES['product_file']['name']= $files['product_file']['name'];
                $_FILES['product_file']['type']= $files['product_file']['type'];
                $_FILES['product_file']['tmp_name']= $files['product_file']['tmp_name'];
                $_FILES['product_file']['error']= $files['product_file']['error'];
                $_FILES['product_file']['size']= $files['product_file']['size'];    
                $type = explode('.', $_FILES['product_file']['name']);
                    
                $this->upload->initialize($this->upload_file());
                $this->upload->do_upload('product_file');
                $file_main = trim('assets/images/product_image/'.$this->upload->file_name);
            
            $main_file =  $file_main; 
            
            
            $this->load->library('upload');
            $infra_file = $_FILES;
                     
                $_FILES['infrastructure_details_file']['name']= $infra_file['infrastructure_details_file']['name'];
                $_FILES['infrastructure_details_file']['type']= $infra_file['infrastructure_details_file']['type'];
                $_FILES['infrastructure_details_file']['tmp_name']= $infra_file['infrastructure_details_file']['tmp_name'];
                $_FILES['infrastructure_details_file']['error']= $infra_file['infrastructure_details_file']['error'];
                $_FILES['infrastructure_details_file']['size']= $infra_file['infrastructure_details_file']['size'];    
                $type = explode('.', $_FILES['infrastructure_details_file']['name']);
                    
                $this->upload->initialize($this->upload_file());
                $this->upload->do_upload('infrastructure_details_file');
                $infra = trim('assets/images/product_image/'.$this->upload->file_name);
            
            $infra_details = $infra;
            
            $data = array(
                'name' => $this->post('product_name'),
                'maintanance_file' => $main_file,
                'infrastructure_details_file' => $infra_details,
                'description' => $this->post('description'),
                'category_id' => $this->post('category_id'),
                'contractor_name' => $this->post('contractor_name'), 
                'project_manager' => $this->post('project_manager'),
                'agreement_number' => $this->post('agreement_number'),   
                'scheduled_start_date' => date('Y-m-d',$this->post('scheduled_start_date')),   
                'scheduled_end_date' => date('Y-m-d',$this->post('scheduled_end_date')),
                'actual_start_date' => date('Y-m-d',$this->post('actual_start_date')),
                'actual_end_date' => date('Y-m-d',$this->post('actual_end_date')),
                'amount_put_to_tender' => $this->post('amount_put_to_tender'),
                'contract_amount' => $this->post('contract_amount'),
                'fund_released' => $this->post('fund_released'),
                'expenditure' => date('Y-m-d',$this->post('expenditure')),
                'status' => $this->post('status'), 
                'year' => $this->post('year_id'),
                'contract_period' => $this->post('contract_period'),
                'district_name' => $this->input->post('district_id'),  
                'taluk_name' => $this->input->post('taluk_id'),  
                'plinth_area_sq' => $this->post('plinth_area_sq'),
                'actual_execution_period' => $this->post('actual_execution_period'),
                'active' => '1',
                'created_at' => date('Y-m-d h:i')
            );
            
            $maintanence = $this->model_products->create($data);

     
            if($maintanence == true)
            {
                   // Set the response and exit
                    $this->response([
                        'status' => TRUE,
                        'message' => 'Record Create successful.',
                        ], REST_Controller::HTTP_OK);
                            
            }else{
                    $this->response([
                          'status' => FALSE,
                          'message' => 'Invalid Parameter'
                      ],REST_Controller::HTTP_BAD_REQUEST); 
           }     
       
    }
    
    
    public function search_post()
    {
        
        $body = file_get_contents('php://input');
        $object = json_decode($body);
        
        $cond2 = $object->taluk_id;
        $cond3 = $object->year_id;
        $cond = $object->district_id;
        $cond1 = $object->category_id;
    
        $this->db->select('*');

		$this->db->from('products');

		if($cond!='')

		{

		$this->db->where(array('district_name'=>$cond));

		}

		if($cond1 !='')

		{

			$this->db->where(array('category_id'=>$cond1));

		}
		
		if($cond2 !='')

		{

			$this->db->where(array('taluk_name'=>$cond2));

		}

	

		if($cond3 !='')

		{

			$this->db->where(array('year'=>$cond3));

		}

		$query = $this->db->get();
        // echo $this->db->last_query();exit;
        if(count($query->result_array())>0)
        {
            $this->response($query->result_array());
        }else{
               
                   // Set the response and exit
                    $this->response([
                        'status' => FALSE,
                        'message' => 'Record empty.',
                        ], REST_Controller::HTTP_OK);
                           
        }
        
    }
    
    private function set_upload_options()
    {   
        //upload an image options
        $config = array();
        $config['upload_path'] = 'assets/images/product_image';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'jpg|png|jpeg|gif';
        $config['max_size']      = 2000;
        $config['overwrite']     = FALSE;

        return $config;
    }
    
    public function upload_image()
    {
        // assets/images/product_image
        $config['upload_path'] = 'assets/images/product_image';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = '1000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('product_image'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['product_image']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    }
    
   private function upload_file()
    {   
        //upload an image options
        $config = array();
        $config['upload_path'] = 'assets/images/product_image';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'pdf|doc|docx|xls|xlsx';
        $config['max_size']      = 2000;
        $config['overwrite']     = FALSE;

        return $config;
    }
    
}