<?php

defined('BASEPATH') OR exit('No direct script access allowed');

date_default_timezone_set('Asia/Kolkata');

class Products extends Admin_Controller 
{
	public function __construct()
	{
		parent::__construct();

		$this->not_logged_in();

		$this->data['page_title'] = 'Products';
        
        $this->load->model('model_users');
		$this->load->model('model_products');
		$this->load->model('model_category');
		$this->load->model('model_stores');
	}

    /* 
    * It only redirects to the manage product page
    */
	public function index()
	{
        if(!in_array('viewProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }

		$this->render_template('products/index', $this->data);	
	}

    /*
    * It Fetches the products data from the product table 
    * this function is called from the datatable ajax function
    */
	public function fetchProductData()
	{
        if(!in_array('viewProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }
        
		$result = array('data' => array());

		$data = $this->model_products->select('products',array('category_id'=>'4'))->result_array();

        if( $data ) 
        {
            foreach ($data as $key => $value) 
            {
                // button
                $buttons = '';
                if(in_array('updateProduct', $this->permission)) {
                    $buttons .= '<a href="'.base_url('products/update/'.$value['id']).'" class="btn btn-default"><i class="fa fa-pencil"></i></a>';
                }

                if(in_array('deleteProduct', $this->permission)) { 
                    $buttons .= ' <button type="button" class="btn btn-default" onclick="removeFunc('.$value['id'].')" data-toggle="modal" data-target="#removeModal"><i class="fa fa-trash"></i></button>';
                }
                
                if(file_exists($value['maintanance_file']))
                {
                $img = '<a href="'.base_url($value['maintanance_file']).'" alt="'.$value['maintanance_file'].'"> Download </a>';
                }else{
                    $img = 'No file';
                }


                if($value['district_name'])
                {
                    $d_name = $this->model_users->select('district',array('id'=>$value['district_name']))->row_array();
                    $district = $d_name['name'];
                }else{
                    $district = '';
                }


                if($value['taluk_name'])
                {
                    $t_name = $this->model_users->select('taluk',array('id'=>$value['taluk_name']))->row_array();
                    $taluk = $t_name['name'];
                }else{
                    $taluk = '';
                }
                
                if($value['project_manager'])
                {
                  $m_name = $this->model_users->select('users',array('id'=>$value['project_manager']))->row_array();
                  $manager = $m_name['username'];
                }else{
                    $manager = '';
                }
                
                $availability = ($value['active'] == 1) ? '<span class="label label-success">Ongoing</span>' : '<span class="label label-warning">Complete</span>';

                $result['data'][$key] = array(
                    $img,
                    $value['name'],
                    $manager,
                    $district,
                    $taluk,
                    $availability,
                    $buttons
                );
            } // /foreach
        }
		echo json_encode($result);
	}	

    
    public function stadium()
    {
        if(!in_array('viewProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }

        $this->render_template('products/stadium', $this->data);  
    }

    public function fetchStadiumData()
    {
        if(!in_array('viewProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }
        
        $result = array('data' => array());

        $data = $this->model_products->select('products',array('category_id'=>5))->result_array();
      
        if( $data ) {
            foreach ($data as $key => $value) {

                // button
                $buttons2 = '';
                if(in_array('updateProduct', $this->permission)) {
                    $buttons2 .= '<a href="'.base_url('products/update/'.$value['id']).'" class="btn btn-default"><i class="fa fa-pencil"></i></a>';
                }

                if(in_array('deleteProduct', $this->permission)) { 
                    $buttons2 .= ' <button type="button" class="btn btn-default" onclick="removeFunc('.$value['id'].')" data-toggle="modal" data-target="#removeModal"><i class="fa fa-trash"></i></button>';
                }
                
                if(file_exists($value['maintanance_file']))
                {
                $img2 = '<a href="'.base_url($value['maintanance_file']).'" alt="'.$value['maintanance_file'].'"> Download </a>';
                }else{
                    $img2 = 'No file';
                }

                
                if($value['district_name'])
                {
                    $d_name2 = $this->model_users->select('district',array('id'=>$value['district_name']))->row_array();
                    $district2 = $d_name2['name'];
                }else{
                    $district2 = '';
                }


                if($value['taluk_name'])
                {
                    $t_name2 = $this->model_users->select('taluk',array('id'=>$value['taluk_name']))->row_array();
                    $taluk2 = $t_name2['name'];
                }else{
                    $taluk2 = '';
                }


                if($value['project_manager'])
                {
                  $m_name2 = $this->model_users->select('users',array('id'=>$value['project_manager']))->row_array();
                  $manager2 = $m_name2['username'];
                }else{
                    $manager2 = '';
                }

                $availability2 = ($value['active'] == 1) ? '<span class="label label-success">Ongoing</span>' : '<span class="label label-warning">Complete</span>';

                $result['data'][$key] = array(
                    $img2,
                    $value['name'],
                    $manager2,
                    $district2,
                    $taluk2,
                    $availability2,
                    $buttons2
                );
            } // /foreach
        }

            

        echo json_encode($result);
    }   
     
    
    public function projects()
    {
        if(!in_array('viewProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }

        $this->render_template('products/projects', $this->data);  
    }

    public function fetchProjectsData()
    {
        if(!in_array('viewProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }
        
        $result = array('data' => array());

        $data = $this->model_products->select('products',array('category_id'=>6))->result_array();

        if( $data ) {
            foreach ($data as $key => $value) {

                // button
                $buttons = '';
                if(in_array('updateProduct', $this->permission)) {
                    $buttons .= '<a href="'.base_url('products/update/'.$value['id']).'" class="btn btn-default"><i class="fa fa-pencil"></i></a>';
                }

                if(in_array('deleteProduct', $this->permission)) { 
                    $buttons .= ' <button type="button" class="btn btn-default" onclick="removeFunc('.$value['id'].')" data-toggle="modal" data-target="#removeModal"><i class="fa fa-trash"></i></button>';
                }
                
                if(file_exists($value['maintanance_file']))
                {
                $img = '<a href="'.base_url($value['maintanance_file']).'" alt="'.$value['maintanance_file'].'"> Download </a>';
                }else{
                    $img = 'No file';
                }

                
                if($value['district_name'])
                {
                    $d_name = $this->model_users->select('district',array('id'=>$value['district_name']))->row_array();
                    $district = $d_name['name'];
                }else{
                    $district = '';
                }


                if($value['taluk_name'])
                {
                    $t_name = $this->model_users->select('taluk',array('id'=>$value['taluk_name']))->row_array();
                    $taluk = $t_name['name'];
                }else{
                    $taluk = '';
                }


                if($value['project_manager'])
                {
                  $m_name = $this->model_users->select('users',array('id'=>$value['project_manager']))->row_array();
                  $manager = $m_name['username'];
                }else{
                    $manager = '';
                }

                $availability = ($value['active'] == 1) ? '<span class="label label-success">Ongoing</span>' : '<span class="label label-warning">Complete</span>';

                $result['data'][$key] = array(
                    $img,
                    $value['name'],
                    $manager,
                    $district,
                    $taluk,
                    $availability,
                    $buttons
                );
            } // /foreach
        }

            

        echo json_encode($result);
    }    

    
    public function maintanance()
    {
        if(!in_array('viewProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }

        $this->render_template('products/maintanance', $this->data);  
    }

    public function fetchMaintananceData()
    {
        if(!in_array('viewProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }
        
        $result = array('data' => array());

        $data = $this->model_products->select('products',array('category_id'=>7))->result_array();

        if( $data ) {
            foreach ($data as $key => $value) {

                // button
                $buttons = '';
                if(in_array('updateProduct', $this->permission)) {
                    $buttons .= '<a href="'.base_url('products/update/'.$value['id']).'" class="btn btn-default"><i class="fa fa-pencil"></i></a>';
                }

                if(in_array('deleteProduct', $this->permission)) { 
                    $buttons .= ' <button type="button" class="btn btn-default" onclick="removeFunc('.$value['id'].')" data-toggle="modal" data-target="#removeModal"><i class="fa fa-trash"></i></button>';
                }
                
                if(file_exists($value['maintanance_file']))
                {
                $img = '<a href="'.base_url($value['maintanance_file']).'" alt="'.$value['maintanance_file'].'"> Download </a>';
                }else{
                    $img = 'No file';
                }

                if($value['district_name'])
                {
                    $d_name = $this->model_users->select('district',array('id'=>$value['district_name']))->row_array();
                    $district = $d_name['name'];
                }else{
                    $district = '';
                }


                if($value['taluk_name'])
                {
                    $t_name = $this->model_users->select('taluk',array('id'=>$value['taluk_name']))->row_array();
                    $taluk = $t_name['name'];
                }else{
                    $taluk = '';
                }

                if($value['project_manager'])
                {
                  $m_name = $this->model_users->select('users',array('id'=>$value['project_manager']))->row_array();
                  $manager = $m_name['username'];
                }else{
                    $manager = '';
                }

                $availability = ($value['active'] == 1) ? '<span class="label label-success">Ongoing</span>' : '<span class="label label-warning">Complete</span>';

                $result['data'][$key] = array(
                    $img,
                    $value['name'],
                    $manager,
                    $district,
                    $taluk,
                    $availability,
                    $buttons
                );
            } // /foreach
        }

            

        echo json_encode($result);
    }   

    /*
    * If the validation is not valid, then it redirects to the create page.
    * If the validation for each input field is valid then it inserts the data into the database 
    * and it stores the operation message into the session flashdata and display on the manage product page
    */
	public function create()
	{
		if(!in_array('createProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }

		$this->form_validation->set_rules('product_name', 'Project name', 'trim|required');
		$this->form_validation->set_rules('active', 'Status', 'trim|required');
		$this->form_validation->set_rules('category', 'Category', 'trim|required');
		$this->form_validation->set_rules('contract_amount', 'Amount', 'trim|required');
		$this->form_validation->set_rules('year_id', 'Product name', 'trim|required');
		$this->form_validation->set_rules('district_name', 'Active', 'trim|required');
		$this->form_validation->set_rules('taluk_name', 'Active', 'trim|required');
		
	
        if ($this->form_validation->run() == TRUE) {
        
            $this->load->library('upload');

            $dataInfo = array();
            $files = $_FILES;
            $cpt = count($_FILES['product_image']['name']);
                
            for($i=0; $i<$cpt; $i++)
            {           
                $_FILES['product_image']['name']= $files['product_image']['name'][$i];
                $_FILES['product_image']['type']= $files['product_image']['type'][$i];
                $_FILES['product_image']['tmp_name']= $files['product_image']['tmp_name'][$i];
                $_FILES['product_image']['error']= $files['product_image']['error'][$i];
                $_FILES['product_image']['size']= $files['product_image']['size'][$i];    
                $type = explode('.', $_FILES['product_image']['name']);
                $type = $type[count($type) - 1];
                    
                $this->upload->initialize($this->upload_files());
                $this->upload->do_upload('product_image');
                $dataInfo[] = trim('assets/images/product_image/'.$this->upload->file_name);
                
            }
            $im = json_encode($dataInfo);
        
            $this->load->library('upload');
            $files_m = $_FILES;
                     
                $_FILES['product_file']['name']= $files_m['product_file']['name'];
                $_FILES['product_file']['type']= $files_m['product_file']['type'];
                $_FILES['product_file']['tmp_name']= $files_m['product_file']['tmp_name'];
                $_FILES['product_file']['error']= $files_m['product_file']['error'];
                $_FILES['product_file']['size']= $files_m['product_file']['size'];    
                $type = explode('.', $_FILES['product_file']['name']);
                    
                $this->upload->initialize($this->set_upload_options());
                $this->upload->do_upload('product_file');
                $maintain = trim('assets/images/product_image/'.$this->upload->file_name);
            
            $main =  $maintain;
            
            
            $this->load->library('upload');
            $infra_file = $_FILES;
                     
                $_FILES['infrastructure_details_file']['name']= $infra_file['infrastructure_details_file']['name'];
                $_FILES['infrastructure_details_file']['type']= $infra_file['infrastructure_details_file']['type'];
                $_FILES['infrastructure_details_file']['tmp_name']= $infra_file['infrastructure_details_file']['tmp_name'];
                $_FILES['infrastructure_details_file']['error']= $infra_file['infrastructure_details_file']['error'];
                $_FILES['infrastructure_details_file']['size']= $infra_file['infrastructure_details_file']['size'];    
                $type = explode('.', $_FILES['infrastructure_details_file']['name']);
                    
                $this->upload->initialize($this->set_upload_options());
                $this->upload->do_upload('infrastructure_details_file');
                $infra = trim('assets/images/product_image/'.$this->upload->file_name);
            
            $infra_details = $infra;
            
        	$data = array(
        		'name' => $this->input->post('product_name'),
                'image' => $im,
                'maintanance_file' => $main,
                'infrastructure_details_file' => $infra_details,
        		'description' => $this->input->post('description'),
        		'category_id' => $this->input->post('category'),
                'contractor_name' => $this->input->post('contractor_name'), 
                'project_manager' => $this->input->post('groups'),
                'agreement_number' => $this->input->post('agreement_number'),   
                'scheduled_start_date' => $this->input->post('scheduled_start_date'),   
                'scheduled_end_date' => $this->input->post('scheduled_end_date'),
                'actual_start_date' => $this->input->post('actual_start_date'),
                'actual_end_date' => $this->input->post('actual_end_date'),
                'amount_put_to_tender' => $this->input->post('amount_put_to_tender'),
                'contract_amount' => $this->input->post('contract_amount'),
                'fund_released' => $this->input->post('fund_released'),
                'expenditure' => $this->input->post('expenditure'),
                'remaining_amount' => $this->input->post('remaining_amount'),
                'status' => $this->input->post('status'),
                'year' => $this->input->post('year_id'), 
                'contract_period' => $this->input->post('contract_period'),
                'district_name' => $this->input->post('district_name'),  
                'taluk_name' => $this->input->post('taluk_name'),  
                'plinth_area_sq' => $this->input->post('plinth_area_sq'),
                'actual_execution_period' => $this->input->post('actual_execution_period'),
        		'active' => $this->input->post('active'),
        		'created_at' => date('Y-m-d h:i a')
        	);

        	$create = $this->model_products->create($data);
        	if($create == true) {
        		$this->session->set_flashdata('success', 'Successfully created');
        		redirect('products/', 'refresh');
        	}
        	else {
        		$this->session->set_flashdata('errors', 'Error occurred!!');
        		redirect('products/create', 'refresh');
        	}
        }
        else {
     
            $user_data = $this->model_users->getUserData();

            $result = array();
            foreach ($user_data as $k => $v) {

                $result[$k]['user_info'] = $v;

                $group = $this->model_users->getUserGroup($v['id']);
                $result[$k]['user_group'] = $group;
            }

            $this->data['user_data'] = $result;
        	
			$this->data['category'] = $this->model_category->getActiveCategory();        	
			$this->data['stores'] = $this->model_stores->getActiveStore();        	
            $this->data['district'] = $this->model_users->select('district')->result_array();
            $this->data['taluk'] = $this->model_users->select('taluk')->result_array();
            $this->data['year'] = $this->model_users->select('year')->result_array();

            $this->render_template('products/create', $this->data);
        }	
	}



    public function create_maintanence()
    {

		$this->form_validation->set_rules('product_name', 'Project name', 'trim|required');
		$this->form_validation->set_rules('active', 'Status', 'trim|required');
		$this->form_validation->set_rules('category', 'Category', 'trim|required');
		$this->form_validation->set_rules('contract_amount', 'Amount', 'trim|required');
		$this->form_validation->set_rules('year_id', 'Product name', 'trim|required');
		$this->form_validation->set_rules('district_name', 'Active', 'trim|required');
		$this->form_validation->set_rules('taluk_name', 'Active', 'trim|required');
		
    
        if ($this->form_validation->run() == TRUE) {
     
            $file = $this->upload_image();
            
            
            $this->load->library('upload');
            $main_infra_file = $_FILES;
                     
                $_FILES['infrastructure_details_file']['name']= $main_infra_file['infrastructure_details_file']['name'];
                $_FILES['infrastructure_details_file']['type']= $main_infra_file['infrastructure_details_file']['type'];
                $_FILES['infrastructure_details_file']['tmp_name']= $main_infra_file['infrastructure_details_file']['tmp_name'];
                $_FILES['infrastructure_details_file']['error']= $main_infra_file['infrastructure_details_file']['error'];
                $_FILES['infrastructure_details_file']['size']= $main_infra_file['infrastructure_details_file']['size'];    
                $type = explode('.', $_FILES['infrastructure_details_file']['name']);
                    
                $this->upload->initialize($this->set_upload_options());
                $this->upload->do_upload('infrastructure_details_file');
                $main_infra = trim('assets/images/product_image/'.$this->upload->file_name);
            
            $main_infra_details = $main_infra;
            
            $data = array(
                'name' => $this->input->post('product_name'),
                'maintanance_file' => $file,
                'infrastructure_details_file' => $main_infra_details,
                'description' => $this->input->post('description'),
                'category_id' => $this->input->post('category'),
                'contractor_name' => $this->input->post('contractor_name'), 
                'project_manager' => $this->input->post('groups'),
                'agreement_number' => $this->input->post('agreement_number'),   
                'scheduled_start_date' => $this->input->post('scheduled_start_date'),   
                'scheduled_end_date' => $this->input->post('scheduled_end_date'),
                'actual_start_date' => $this->input->post('actual_start_date'),
                'actual_end_date' => $this->input->post('actual_end_date'),
                'amount_put_to_tender' => $this->input->post('amount_put_to_tender'),
                'contract_amount' => $this->input->post('contract_amount'),
                'fund_released' => $this->input->post('fund_released'),
                'expenditure' => $this->input->post('expenditure'),
                'remaining_amount' => $this->input->post('remaining_amount'),
                'status' => $this->input->post('status'),
                'year' => $this->input->post('year_id'), 
                'contract_period' => $this->input->post('contract_period'),
                'district_name' => $this->input->post('district_name'),  
                'taluk_name' => $this->input->post('taluk_name'),  
                'plinth_area_sq' => $this->input->post('plinth_area_sq'),
                'actual_execution_period' => $this->input->post('actual_execution_period'),
                'active' => $this->input->post('active'),
                'created_at' => date('Y-m-d h:i a')
            );

            $create = $this->model_products->create($data);
            if($create == true) {
                $this->session->set_flashdata('success', 'Successfully created');
                redirect('products/', 'refresh');
            }
            else {
                $this->session->set_flashdata('errors', 'Error occurred!!');
                redirect('products/create_maintanence', 'refresh');
            }
        }
        else {
            // false case

            // attributes 
            // $attribute_data = $this->model_attributes->getActiveAttributeData();


            // $this->data['attributes'] = $attributes_final_data;
            // $this->data['brands'] = $this->model_brands->getActiveBrands();
            $user_data = $this->model_users->getUserData();

            $result = array();
            foreach ($user_data as $k => $v) {

                $result[$k]['user_info'] = $v;

                $group = $this->model_users->getUserGroup($v['id']);
                $result[$k]['user_group'] = $group;
            }

            $this->data['user_data'] = $result;
            
            $this->data['stores'] = $this->model_stores->getActiveStore();          
            $this->data['district'] = $this->model_users->select('district')->result_array();
            $this->data['taluk'] = $this->model_users->select('taluk')->result_array();
            $this->data['year'] = $this->model_users->select('year')->result_array();

            $this->render_template('products/create_maintanence', $this->data);
        }   
    }

    /*
    * If the validation is not valid, then it redirects to the edit product page 
    * If the validation is successfully then it updates the data into the database 
    * and it stores the operation message into the session flashdata and display on the manage product page
    */
	public function update($product_id)
	{      
        if(!in_array('updateProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }

        if(!$product_id) {
            redirect('dashboard', 'refresh');
        }

        $this->form_validation->set_rules('product_name', 'Product name', 'trim|required');
        $this->form_validation->set_rules('active', 'active', 'trim|required');

        if ($this->form_validation->run() == TRUE) {
            // true case
            
            $data = array(
                'name' => $this->input->post('product_name'),
                'description' => $this->input->post('description'),
                'category_id' => $this->input->post('category'),
                'contractor_name' => $this->input->post('contractor_name'), 
                'project_manager' => $this->input->post('groups'),
                'agreement_number' => $this->input->post('agreement_number'),   
                'scheduled_start_date' => $this->input->post('scheduled_start_date'),   
                'scheduled_end_date' => $this->input->post('scheduled_end_date'),
                'actual_start_date' => $this->input->post('actual_start_date'),
                'actual_end_date' => $this->input->post('actual_end_date'),
                'amount_put_to_tender' => $this->input->post('amount_put_to_tender'),
                'contract_amount' => $this->input->post('contract_amount'),
                'fund_released' => $this->input->post('fund_released'),
                'expenditure' => $this->input->post('expenditure'),
                'remaining_amount' => $this->input->post('remaining_amount'),
                'status' => $this->input->post('status'), 
                'year' => $this->input->post('year_id'),
                'contract_period' => $this->input->post('contract_period'),
                'district_name' => $this->input->post('district_name'),
                'taluk_name' => $this->input->post('taluk_name'),
                'plinth_area_sq' => $this->input->post('plinth_area_sq'),
                'actual_execution_period' => $this->input->post('actual_execution_period'),
                'active' => $this->input->post('active'),
            );

            
            if($_FILES['product_file']['size'] > 0) {
                $upload_image = $this->upload_image();
                $upload_image = array('maintanance_file' => $upload_image);
                
                $this->model_products->update($upload_image, $product_id);
            }
            
            if($_FILES['infrastructure_details_file']['size'] > 0) {
                $inf_file = $this->upload_image();
                $inf_file = array('infrastructure_details_file' => $inf_file);
                
                $this->model_products->update($inf_file, $product_id);
            }

            $update = $this->model_products->update($data, $product_id);
            if($update == true) {
                $this->session->set_flashdata('success', 'Successfully updated');
                redirect('products/', 'refresh');
            }
            else {
                $this->session->set_flashdata('errors', 'Error occurred!!');
                redirect('products/update/'.$product_id, 'refresh');
            }
        }
        else {
                    
            $this->data['category'] = $this->model_category->getActiveCategory();           
            $this->data['stores'] = $this->model_stores->getActiveStore();          
            $this->data['district'] = $this->model_users->select('district')->result_array();
            $this->data['taluk'] = $this->model_users->select('taluk')->result_array();
             
            $product_data = $this->model_products->getProductData($product_id);
            $this->data['product_data'] = $product_data;
            $this->render_template('products/edit', $this->data); 
        }   
	}
	
    /*
    * This function is invoked from another function to upload the image into the assets folder
    * and returns the image path
    */
	public function upload_image()
    {
    	// assets/images/product_image
        $config['upload_path'] = 'assets/images/product_image';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'pdf|txt|docx|doc|xls|xlsx';
        $config['max_size'] = '1000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('product_file'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['product_file']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    }

    private function set_upload_options()
    {   
        // assets/images/product_image
        $config['upload_path'] = 'assets/images/product_image';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'pdf|txt|doc|docx|xls|xlsx';
        $config['max_size'] = 2000;

        return $config;
    }

    private function upload_files()
    {
        $config = array(
            'upload_path'   => 'assets/images/product_image',
            'file_name'     => $_FILES['product_image']['name'],
            'allowed_types' => 'jpg|gif|png|jpeg',
            'max_size'      => 2000,
            'overwrite'     => 1,                       
        );

        return $config;
    }

    /*
    * It removes the data from the database
    * and it returns the response into the json format
    */
	public function remove()
	{
        if(!in_array('deleteProduct', $this->permission)) {
            redirect('dashboard', 'refresh');
        }
        
        $product_id = $this->input->post('product_id');

        $response = array();
        if($product_id) {
            $delete = $this->model_products->remove($product_id);
            if($delete == true) {
                $response['success'] = true;
                $response['messages'] = "Successfully removed"; 
            }
            else {
                $response['success'] = false;
                $response['messages'] = "Error in the database while removing the product information";
            }
        }
        else {
            $response['success'] = false;
            $response['messages'] = "Refersh the page again!!";
        }

        echo json_encode($response);
	}
    
    public function getTaluk()
    { 
    // POST data 
    $id = $this->input->post('city');

    // get data 
    $data = $this->model_users->select('taluk',array('district_id'=>$id))->result_array();
    echo json_encode($data); 
    }
}