<?php 

class Model_users extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function getUserData($userId = null) 
	{
		if($userId) {
			$sql = "SELECT * FROM users WHERE id = ?";
			$query = $this->db->query($sql, array($userId));
			return $query->row_array();
		}

		$sql = "SELECT * FROM users WHERE id != ? ORDER BY id DESC";
		$query = $this->db->query($sql, array(1));
		return $query->result_array();
	}

	public function getUserGroup($userId = null) 
	{
		if($userId) {
			$sql = "SELECT * FROM user_group WHERE user_id = ?";
			$query = $this->db->query($sql, array($userId));
			$result = $query->row_array();

			$group_id = $result['group_id'];
			$g_sql = "SELECT * FROM groups WHERE id = ?";
			$g_query = $this->db->query($g_sql, array($group_id));
			$q_result = $g_query->row_array();
			return $q_result;
		}
	}

	public function create($data = '', $group_id = null)
	{

		if($data && $group_id) {
			$create = $this->db->insert('users', $data);

			$user_id = $this->db->insert_id();

			$group_data = array(
				'user_id' => $user_id,
				'group_id' => $group_id
			);

			$group_data = $this->db->insert('user_group', $group_data);

			return ($create == true && $group_data) ? true : false;
		}
	}

	public function edit($data = array(), $id = null, $group_id = null)
	{
		$this->db->where('id', $id);
		$update = $this->db->update('users', $data);

		if($group_id) {
			// user group
			$update_user_group = array('group_id' => $group_id);
			$this->db->where('user_id', $id);
			$user_group = $this->db->update('user_group', $update_user_group);
			return ($update == true && $user_group == true) ? true : false;	
		}
			
		return ($update == true) ? true : false;	
	}

	public function delete($id)
	{
		$this->db->where('id', $id);
		$delete = $this->db->delete('users');
		return ($delete == true) ? true : false;
	}

	public function countTotalUsers()
	{
		$sql = "SELECT * FROM users WHERE id != ?";
		$query = $this->db->query($sql, array(1));
		return $query->num_rows();
	}
    
    public function select($table,$cond='',$cond1='',$in='',$infield='') #SELECT

	{

	$this->db->select('*');

	$this->db->from($table);

	if($cond!='')

	{

	$this->db->where($cond);

	}
	
	if($cond1!='')

	{

	$this->db->where($cond1);

	}

	if($in!=''&&$infield!='')

	{

	$this->db->where_in($infield,$in);

	}

	$query = $this->db->get();

	return $query;	

	}

	function select_order($table,$order_id='',$order_order='') #SELECT
	{

		$this->db->select('*');

		$this->db->from($table);


		if($order_id !='' && $order_order !='')

		{

			$this->db->order_by($order_id,$order_order);

		}

		$query = $this->db->get();

		return $query;	

	}

		
	function insert($table,$data) #INSERT

	{

	if($this->db->insert($table,$data))

	return true;

	else

	return false;

	}
	
    
	

	function update($table,$data,$cond)

	{

	if($this->db->update($table,$data,$cond))
     // echo $this->db->last_query();exit;
	return true;

	else

	return false;

	}
  
	public function prev()
	{
	    $sql = "SELECT * FROM `orders` p INNER JOIN order_items o ON p.id=o.order_id WHERE p.id=o.order_id";
	    $query = $this->db->query($sql, array(1));
		return $query->num_rows();
	}

}