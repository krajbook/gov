

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Manage
      <small>Maintanence</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Maintanence</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row">
      <div class="col-md-12 col-xs-12">

        <div id="messages"></div>

        <?php if($this->session->flashdata('success')): ?>
          <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo $this->session->flashdata('success'); ?>
          </div>
        <?php elseif($this->session->flashdata('error')): ?>
          <div class="alert alert-error alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo $this->session->flashdata('error'); ?>
          </div>
        <?php endif; ?>


        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Add Maintanence</h3>
          </div>
          <!-- /.box-header -->
          <form role="form" action="" method="post" enctype="multipart/form-data">
              <div class="box-body">

                <?php echo validation_errors(); ?>
                
                <div class="form-group">

                  <label for="product_image">Maintanence Document (pdf)</label>
                  <input class="form-control" type="file" name="product_file" id="product_file">
                </div>
                
                <div class="form-group">

                  <label for="product_image">Infrastructure Details (xls)</label>
                  <input class="form-control" type="file" name="infrastructure_details_file" id="infrastructure_details_file">
                </div>
                
                <div class="form-group">
                  <label for="groups">District officer</label>
                  <select class="form-control" id="groups" name="groups">
                    <option value="">- Select -</option>
                    <?php foreach ($user_data as $k => $v): 
                      if($v['user_group']['group_name'] == 'District Officer'):?>
                      <option value="<?php echo $v['user_info']['id']; ?>">
                        <?php echo $v['user_info']['firstname']; ?>
                      </option>
                    <?php endif; ?>
                    <?php endforeach ?>
                  </select>
                </div>



                <div class="form-group">
                  <label for="product_name">Project name</label>
                  <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Enter product name" autocomplete="off" value="<?php echo $this->input->post('product_name') ?>" />
                </div>
                
                <div class="form-group">
                  <label for="price">Contractor Name</label>
                  <input type="text" class="form-control" id="contractor_name" name="contractor_name"  autocomplete="off" value="<?php echo $this->input->post('contractor_name') ?>"/>
                </div>

                <div class="form-group">
                  <label for="price">Agreement Number</label>
                  <input type="text" class="form-control" id="agreement_number" name="agreement_number" autocomplete="off" value="<?php echo $this->input->post('agreement_number') ?>"/>
                </div>

                <div class="form-group">
                  <label for="price">Scheduled Start Date</label>
                  <input type="date" class="form-control" id="scheduled_start_date" name="scheduled_start_date" autocomplete="off" value="<?php echo $this->input->post('scheduled_start_date') ?>"/>
                </div>

                <div class="form-group">
                  <label for="price">Scheduled End Date</label>
                  <input type="date" class="form-control" id="scheduled_end_date" name="scheduled_end_date" autocomplete="off" value="<?php echo $this->input->post('scheduled_end_date') ?>"/>
                </div>

                <div class="form-group">
                  <label for="price">Actual Start Date</label>
                  <input type="date" class="form-control" id="actual_start_date" name="actual_start_date" autocomplete="off" value="<?php echo $this->input->post('actual_start_date') ?>"/>
                </div>

                <div class="form-group">
                  <label for="price">Actual End Date</label>
                  <input type="date" class="form-control" id="actual_end_date" name="actual_end_date" autocomplete="off" value="<?php echo $this->input->post('actual_end_date') ?>"/>
                </div>

                <div class="form-group">
                  <label for="price">Amount Tender</label>
                  <input type="text" class="form-control" id="amount_put_to_tender" name="amount_put_to_tender" autocomplete="off" value="<?php echo $this->input->post('amount_put_to_tender') ?>"/>
                </div>

                <div class="form-group">
                  <label for="price">Contract Amount</label>
                  <input type="text" class="form-control" id="contract_amount" name="contract_amount" autocomplete="off" value="<?php echo $this->input->post('contract_amount') ?>"/>
                </div>

                <div class="form-group">
                  <label for="price">Contract Period</label>
                  <input type="text" class="form-control" id="contract_period" name="contract_period"  autocomplete="off" value="<?php echo $this->input->post('contract_period') ?>"/>
                </div>

                <div class="form-group">
                  <label for="price">Fund Released</label>
                  <input type="text" class="form-control" id="fund_released" name="fund_released"  autocomplete="off" value="<?php echo $this->input->post('fund_released') ?>"/>
                </div>
                
                
                <div class="form-group">
                  <label for="price">Expenditure</label>
                  <input type="date" class="form-control" id="expenditure" name="expenditure"  autocomplete="off" value="<?php echo $this->input->post('expenditure') ?>"/>
                </div>

                <div class="form-group">
                  <label for="price">District</label>
                  <select class="form-control" id="sel_city" name="district_name"> 
                     <option>Select District</option>
                     <?php foreach($district as $dt){ ?>
                     <option value="<?php echo $dt['id']; ?>"><?php echo $dt['name']; ?></option>
                     <?php }?>
                  </select>
                </div>


                <div class="form-group">
                  <label for="price">Taluk</label>
                  <select class="form-control" name="taluk_name" id='sel_taluk'>
                    <option>-- Select taluk --</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="price">Area SQM</label>
                  <input type="text" class="form-control" id="  plinth_area_sq" name="  plinth_area_sq" autocomplete="off" value="<?php echo $this->input->post(' plinth_area_sq') ?>"/>
                </div>

                
                <div class="form-group">
                  <label for="price">Actual Execution Period</label>
                  <input type="text" class="form-control" id="actual_execution_period" name="actual_execution_period" autocomplete="off" value="<?php echo $this->input->post('actual_execution_period') ?>"/>
                </div>

                <div class="form-group">
                  <label for="description">Description</label>
                  <textarea type="text" class="form-control" id="description" row="3" name="description" placeholder="Enter description" autocomplete="off">
                  </textarea>
                </div>

                <div class="form-group">
                  <label for="description">Total Remaining Amount</label>
                  <input type="text" class="form-control" id="remaining_amount" value="<?php echo $this->input->post('remaining_amount') ?>" name="remaining_amount" autocomplete="off"/>
                </div>

                <div class="form-group">
                  <label for="category">Category</label>
                  <select class="form-control select_group" id="category" name="category">
                    <option>- Select -</option>
                      <option value="7">Maintanence</option>
                  </select>
                </div>
                
                <div class="form-group">
                  <label for="store">Year</label>
                  <select class="form-control" id="year_id" name="year_id">
                    <option>Select</option>
                    <?php foreach($year as $yr) {?>
                    <option value="<?php echo $yr['id'] ?>"><?php echo $yr['year'] ?></option>
                    <?php } ?>
                  </select>
                </div>

                <div class="form-group">
                  <label for="store">Status</label>
                  <select class="form-control" id="active" name="active">
                    <option value="1">Ongoing</option>
                    <option value="2">Complete</option>
                  </select>
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <a href="<?php echo base_url('products/') ?>" class="btn btn-warning">Back</a>
              </div>
            </form>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- col-md-12 -->
    </div>
    <!-- /.row -->
    

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
    $(".select_group").select2();
    $("#description").wysihtml5();

    $("#productMainNav").addClass('active');
    $("#createProductSubMenu").addClass('active');
    
    var btnCust = '<button type="button" class="btn btn-secondary" title="Add picture tags" ' + 
        'onclick="alert(\'Call your custom code here.\')">' +
        '<i class="glyphicon glyphicon-tag"></i>' +
        '</button>'; 
    $("#product_image").fileinput({
        overwriteInitial: true,
        maxFileSize: 1500,
        showClose: false,
        showCaption: false,
        browseLabel: '',
        removeLabel: '',
        browseIcon: '<i class="glyphicon glyphicon-folder-open"></i>',
        removeIcon: '<i class="glyphicon glyphicon-remove"></i>',
        removeTitle: 'Cancel or reset changes',
        elErrorContainer: '#kv-avatar-errors-1',
        msgErrorClass: 'alert alert-block alert-danger',
        // defaultPreviewContent: '<img src="/uploads/default_avatar_male.jpg" alt="Your Avatar">',
        layoutTemplates: {main2: '{preview} ' +  btnCust + ' {remove} {browse}'},
        allowedFileExtensions: ["pdf", "doc", "docx"]
    });

  });


// baseURL variable
  var base_url = "<?php echo base_url(); ?>";
 
  $(document).ready(function(){
     
    // City change
    $('#sel_city').change(function(){
      var city = $(this).val();
       
      // AJAX request
      $.ajax({
        url: base_url + '/products/getTaluk',
        method: 'post',
        data: {city: city},
        dataType: 'json',
        success: function(response){

          // Remove options 
          $('#sel_taluk').find('option').not(':first').remove();

          // Add options
          $.each(response,function(index,data){
             $('#sel_taluk').append('<option value="'+data['id']+'">'+data['name']+'</option>');
          });
        }
     });
   });
  });
</script>