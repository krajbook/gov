
  <!--<footer class="main-footer">-->
  <!--  <strong>Copyright &copy; <?php echo date('Y'); ?></strong>-->
  <!--</footer>-->

  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

</body>
</html>
