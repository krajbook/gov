<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
</head>
<body>
<form method="POST" action="http://localhost/chillkrt/admin-ksphc/api/work">
    <input type="file" name="product_image[]" id="product_image[]" multiple/>
    <input type="text" name="product_name" value="Main">
    <input type="text" name="category_id" value="5">
    <input type="submit" name="submit">
</form>
</body>
</html>
