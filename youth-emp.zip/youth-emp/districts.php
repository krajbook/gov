
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>

</title><link href="Css/style.css" rel="stylesheet" type="text/css" />

<link href="Images/stylesheet.css" type="text/css" rel="Stylesheet" />
<link href="Images/inside_css.css" type="text/css" rel="Stylesheet" />
    <style type="text/css">
        .kd {
  background-color: #eee;
  width: 93vh;
  height: 180vh;

  overflow: scroll;
}
    </style>
   <script type="text/javascript">
       function googleTranslateElementInit() {
           new google.translate.TranslateElement({ pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE }, 'google_translate_element');
       }</script>
       <script type="text/javascript">
           function SetScrollDir(elem) {
               var marquee = document.getElementById("myMarquee");

               // Returns the index of the selected option
               var whichSelected = elem.selectedIndex;

               if ('direction' in marquee) {
                   marquee.direction = elem.options[whichSelected].text;
                   //onmouseover="this.setAttribute('scrollamount', 0, 0)

               } else {
                   // Google Chrome and Safari
                   marquee.setAttribute("direction", elem.options[whichSelected].text);

               }
           }
    </script>
    <script type="text/javascript">

        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-28954017-1']);
        _gaq.push(['_trackPageview']);

        (function () {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
        })();

        function opennewtab() {
            var path = "#";
            window.open(path, '_blank')
        }
        function opennewtabVer2() {
            var path = "#";
            window.open(path, '_blank')
        }
        function opennewtabksphcmail() {
            var path = "#";
            window.open(path, '_blank')
        }
</script>
</head>
<body>
    <form method="post" action="#" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwULLTE0MDc1NTE4MjIPZBYCAgMPZBYCAl0PFgIeA3NyYwUNcHJvamVjdHMuYXNweGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgYFCmltZ2J0bkhvbWUFDEltYWdlQnV0dG9uMgUMSW1hZ2VCdXR0b24zBQxJbWFnZUJ1dHRvbjQFDEltYWdlQnV0dG9uNQUKSW1hS2FubmFkYY4o85F2dOP+gqZNLSyDQc72bLyN57+hyjxNCTOL0tdU" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<div class="aspNetHidden">

  <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="BCD81B8F" />
  <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAB3ywnS6IiuO+FCez9fnRELqAnreYlBWGSbWZ8PzZFVLGWLNV+2mZgnOAlNG5DVTg1vmrIx4Wzwbb1QZEjNCy6X4s+V9YTPCBDtGD4sSt9Nib13DazDmkpv+1rup7qinWaXW4H1AU2UapMn4+CE+FNJnr2mc5Bt6yMtxyRV/lyoHxz9YyyR4qjX0bKJ2X6bXV1Mvi1zv2zfvxmivUuslpagQqwThxiK0R3ZpqlwJgLvz6eYJKAPvp/8fDtxsMkj4WBm6f/9NVk/cD/N0P2pPUCLCbVD2Bs+oC+tVhisurIK4jIQxN4qwIfu78ABciZ/pEget6xb6ifsImJWFt5ut/PhJw+GtQvDhezJVVb+XXqASm4Pd4rpa/HsyBIhviniftdcrWSIgdvPCkMS8bYh6UKiofBKnF5XohMZP3byzFe1fR6+yCT9y/ysNwbc+94fxSn95WP7NuKNyRVSCk9bPAr39geQHZPPMsW7iHmlx7SKNA1/ASdfVR25GHQ93iHQLsE542e7jr8w4wgJzDQ3mXC0X7m/lYB9P3Nqym0ffAbWMc+G+YRyUzJ09lQhRVwS1eZARz6SBrTrFSCY8Bk9Anvfk10VNJvK2uiHUU8kn/A80wQB3rD1Y3n5TyZZwY4lrNMZtvJNh1wP27KJbHLxyKbkq" />
</div>
     <div style="height: auto;  padding-left: 300px;  padding-right: 300px;  width: 800px;text-align:center;">
            <table style="height: auto;   width: 760px;">
                    <tr>
                        <td>
                            <img id="Image1" src="Images/logo_ksphc_eng1.png" />
                        </td>
                       
                    </tr>
                    
                   
                </table>
                 <table   style="width: 100%;">
                     <tr style="background-color: #fff; height: 40px;">
                        <td style="color: #fff;text-align:center;">
                          
                            <table style="width:100%;">
                            <tr>
                                <td>
                                    <a href="index.html"><img src="Images/home.gif"></a>
                                    <!-- <input type="image" name="imgbtnHome" id="imgbtnHome" src="images/home.gif" /> -->
                                </td>
                                <td>
                                  <a href="projects.php"><img src="Images/projects.gif"></a>
                                    <!-- <input type="image" name="ImageButton4" id="ImageButton4" src="Images/projects.gif" /> -->

                                </td>
                                <td>
                                  <a href="innovation.html"><img src="Images/innovations.gif"></a>
                                    <!-- <input type="image" name="ImageButton5" id="ImageButton5" src="Images/innovations.gif" /> -->
                                </td>
                            </tr>
                        </table>
                        </td>
                         
                    </tr>
                            
                      <tr style="background-color: #50bd1e; height: 40px;padding-top:0px;">
                        

                        <td align="right" style="color: #fff;width:100%;padding-left:20px;font-weight:bold;">             
                            
                            
                         
                             <input type="image" name="ImaKannada" id="ImaKannada" src="Images/kannada.png" onclick="opennewtab();" style="height:20px;width:101px;" />
                           
                        </td>

                      
                    </tr>
                     
                </table>
               <table  style="width: 100%; height:auto;">
                     <tr style="background-color: #fff;">
                       <td style="width:10%; vertical-align:top;height:600px;">
                        
                            <table style="width:100%;">
                                <tr>
                                    <td style="text-align:center;height:30px;">

                                    <table style="width:99%; height: 25px;">
                                           
                                            <tr style="background-color:#f3751a;height:17px;">
                                                <td style="height:20px"; >
                                                    <br />
                                                  <input type="submit" name="btnVer2" value="Login To DOTNET WBPMS" onclick="opennewtabVer2();" id="btnVer2" style="font-weight:bold;height:17px;width:100%;" />
                                                    <br />
                                                    <br />
                                                   
                                                  <input type="submit" name="Button2" value="Login To KSPH&amp;IDCL Mail" onclick="opennewtabksphcmail();" id="Button2" style="font-weight:bold;height:17px;width:100%;" />
                                                   
                                                    <br />
                                                     <br />
                                                   
                                                </td>
                                            </tr>
                                        </table>
                                                                                                                    
                                       
                               
                                <tr>
                                   
                                    
                                </tr>
                               <tr style="background-color:#50bd1e;height:40px;text-align:center;font-weight:bold;">
                                   <td style="color:White">
                                       KSPH&IDCL.ORG
                                   </td>
                               </tr>
                               <tr>
                                   <td style="background-color:#d6f2a1;">
                                       <table style="width:100%;height:auto;">
                                           <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image2" src="Images/arrow.gif" /></td><td style="text-align:left;">
                                                   <a id="lnkhighligh" href="javascript:__doPostBack(&#39;lnkhighligh&#39;,&#39;&#39;)" style="text-decoration:none;">Highlights</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image3" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkfinance" href="javascript:__doPostBack(&#39;lnkfinance&#39;,&#39;&#39;)" style="text-decoration:none;">Financials</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image4" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkaccout" href="javascript:__doPostBack(&#39;lnkaccout&#39;,&#39;&#39;)" style="text-decoration:none;">Accountability</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image5" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkvisit" href="javascript:__doPostBack(&#39;lnkvisit&#39;,&#39;&#39;)" style="text-decoration:none;">Vision</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image6" src="Images/arrow.gif" /></td><td  style="text-align:left;"><a id="lnkmission" href="javascript:__doPostBack(&#39;lnkmission&#39;,&#39;&#39;)" style="text-decoration:none;">Mission</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image9" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkscheme" href="javascript:__doPostBack(&#39;lnkscheme&#39;,&#39;&#39;)" style="text-decoration:none;">Status Of Projects</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image7" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkawards" href="javascript:__doPostBack(&#39;lnkawards&#39;,&#39;&#39;)" style="text-decoration:none;">Awards</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image8" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkpolicy" href="javascript:__doPostBack(&#39;lnkpolicy&#39;,&#39;&#39;)" style="text-decoration:none;">Policies & Procedures</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image10" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkcomplaint" href="javascript:__doPostBack(&#39;lnkcomplaint&#39;,&#39;&#39;)" style="text-decoration:none;">Complaints</a></td>
                                           </tr>
                                            
                                           
                                           
                                           <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image13" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnktestimonials" href="javascript:__doPostBack(&#39;lnktestimonials&#39;,&#39;&#39;)" style="text-decoration:none;">Testimonials</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image14" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkpolicedeptst" href="javascript:__doPostBack(&#39;lnkpolicedeptst&#39;,&#39;&#39;)" style="text-decoration:none;">Police Dpt websites Links</a></td>
                                           </tr>

                                           
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image17" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkRTI" href="javascript:__doPostBack(&#39;lnkRTI&#39;,&#39;&#39;)" style="text-decoration:none;">RTI</a></td>
                                           </tr>

                                           <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image18" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnknewcontr" href="javascript:__doPostBack(&#39;lnknewcontr&#39;,&#39;&#39;)" style="text-decoration:none;">Contractor Registeration</a></td>
                                           </tr>

                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image16" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkcontactus" href="javascript:__doPostBack(&#39;lnkcontactus&#39;,&#39;&#39;)" style="text-decoration:none;">Contact Us</a></td>
                                           </tr>
                                           
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image11" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkmeetng" href="javascript:__doPostBack(&#39;lnkmeetng&#39;,&#39;&#39;)" style="text-decoration:none;">Meetings and Proceedings</a></td>
                                           </tr>


                                           <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image12" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkcareer" href="javascript:__doPostBack(&#39;lnkcareer&#39;,&#39;&#39;)" style="text-decoration:none;">Careers</a></td>
                                           </tr>
                                       </table>
                                   </td>

                               </tr>
                                <tr  style="background-color:#f3751a;height:40px;text-align:center;font-weight:bold;">
                                    <td style="color:White" id="newsdesign">
                                        News
                                    </td>
                                </tr>
                                <tr>
                                    <td style="background-color:#efdcdc;">
                                        <marquee id="myMarquee" style="width:200px; height:575px" direction="up" onmouseover="this.stop();" onmouseout="this.start();">
                                         <table style="width:100%;">
                                          <tr>
                                               <td style="text-justify:auto;">
                                                   KSPH&IDCL has been awarded CIDC Vishwakarma Award 2017 for Achivement Award for Best Professionally Managed Company in Category III - Turnover INR 100-500 Crores. 
                                               </td>
                                           </tr>
                                           <tr>
                                                 <td style="text-align:right;"> <a id="lnkpdfturnover" href="javascript:__doPostBack(&#39;lnkpdfturnover&#39;,&#39;&#39;)"><font color=Red>Read More</font></a></td>
                                             </tr>
                                            <tr>
                                               <td style="text-justify:auto;">
                                               
											    	KSPH&IDCL has been awarded CIDC Vishwakarma Award 2017 for Achivement Award for Best Construction Project for Fast Track Construction Technology for Mysore Project.                                          
                                               </td>
                                           </tr>
                                           <tr>
                                                 <td style="text-align:right;"> <a id="lnkpdfmysore" href="javascript:__doPostBack(&#39;lnkpdfmysore&#39;,&#39;&#39;)"><font color=Red>Read More</font></a></td>
                                             </tr>
                                           <tr>
                                               <td style="text-justify:auto;">
                                                   KSPH&IDCL has been awarded the 4th CIDC Vishwakarma Award 2012 under the category 'Achievement for Best Project' for 'Police Model Flats built in just 15 days' using EPS based pre-fab fast track construction technology.
                                               </td>
                                           </tr>
                                             <tr>
                                                 <td style="text-align:right;"> <a id="lnkpdf" href="javascript:__doPostBack(&#39;lnkpdf&#39;,&#39;&#39;)"><font color=Red>Read More</font></a></td>
                                             </tr>
                                             <tr>
                                                 <td style="text-justify:auto;">
                                                     KSPH&IDCL is certified to ISO 9001-2008 for its Quality Management System.
                                                 </td>
                                             </tr>
                                            <tr>
                                                 <td style="text-align:right;"> <a id="lnkksphcquality" href="javascript:__doPostBack(&#39;lnkksphcquality&#39;,&#39;&#39;)"><font color=Red>Read More</font></a></td>
                                             </tr>
                                             
                                           

                                          </table></marquee>
                                    </td>
                                </tr>
                               
                                 <tr>
                                    
                                </tr>
                               

                            </table>
                        </td>
                     
                        <td id="maincontent" style="width:90%;vertical-align:top;background-color:#f1f1f1">
                          <p style="color:red;">
                <img id="Image1" src="Images/Sqr_ongoing.gif" />
               <a id="lnkongoing" href="javascript:__doPostBack(&#39;lnkongoing&#39;,&#39;&#39;)" style="color:Red;font-weight:bold;text-decoration:none;">Stadium(<span id="lblonging">13</span>)</a>
            </p>
            <p style="color:black;">
                <img id="Image2" src="Images/Sqr_Completed.gif" />
              <a id="lnkcompleted" href="javascript:__doPostBack(&#39;lnkcompleted&#39;,&#39;&#39;)" style="color:black;font-weight:bold;text-decoration:none;">Hostel(<span id="lblcompleted">42</span>)</a>
            </p>
            
            <p style="color:blue;">
                <img id="Image3" src="Images/Sqr_AllProj.gif" />
                <a id="lnkallproj" href="javascript:__doPostBack(&#39;lnkallproj&#39;,&#39;&#39;)" style="color:Blue;font-weight:bold;text-decoration:none;">All Projects(<span id="lblallproj">55</span>)</a>
            </p>
            
            <p style="color:green;">
                <img id="Image2" src="Images/Sqr_Completed.gif" />
              <a id="lnkcompleted" href="javascript:__doPostBack(&#39;lnkcompleted&#39;,&#39;&#39;)" style="color:Green;font-weight:bold;text-decoration:none;">Completed(<span id="lblcompleted">42</span>)</a>
            </p>
            <p>    <a href="bangalore-rural.html">View all scheme</a></p>
                           <?php $name = $_GET['name'];
                              echo "<h1 style='color:black'>".$name."</h1>"; ?>
                           <img width="200vh" height="200vh" src="maps/<?php echo $name ?>.jpg">
                                     
                        </td>
                             
                    </tr>
                   
                </table>
                <table>
                    <tr>
          <td width="800" bgcolor="#c5c5c5" height="16">
            <p align="center">Copyright © 2020 | All Rights Reserved.
            &nbsp;&nbsp;</p></td>
        </tr>
                </table>
            </table>
        </div>
    </form>
</body>
</html>
