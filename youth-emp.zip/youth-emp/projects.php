
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>

</title><link href="Css/style.css" rel="stylesheet" type="text/css" />

<link href="Images/stylesheet.css" type="text/css" rel="Stylesheet" />
<link href="Images/inside_css.css" type="text/css" rel="Stylesheet" />
    <style type="text/css">
        .kd {
  background-color: #eee;
  width: 93vh;
  height: 168vh;

  overflow: scroll;
}
    </style>
   <script type="text/javascript">
       function googleTranslateElementInit() {
           new google.translate.TranslateElement({ pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE }, 'google_translate_element');
       }</script>
       <script type="text/javascript">
           function SetScrollDir(elem) {
               var marquee = document.getElementById("myMarquee");

               // Returns the index of the selected option
               var whichSelected = elem.selectedIndex;

               if ('direction' in marquee) {
                   marquee.direction = elem.options[whichSelected].text;
                   //onmouseover="this.setAttribute('scrollamount', 0, 0)

               } else {
                   // Google Chrome and Safari
                   marquee.setAttribute("direction", elem.options[whichSelected].text);

               }
           }
    </script>
    <script type="text/javascript">

        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-28954017-1']);
        _gaq.push(['_trackPageview']);

        (function () {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
        })();

        function opennewtab() {
            var path = "#";
            window.open(path, '_blank')
        }
        function opennewtabVer2() {
            var path = "#";
            window.open(path, '_blank')
        }
        function opennewtabksphcmail() {
            var path = "#";
            window.open(path, '_blank')
        }
</script>
</head>
<body>
    <form method="post" action="#" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwULLTE0MDc1NTE4MjIPZBYCAgMPZBYCAl0PFgIeA3NyYwUNcHJvamVjdHMuYXNweGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgYFCmltZ2J0bkhvbWUFDEltYWdlQnV0dG9uMgUMSW1hZ2VCdXR0b24zBQxJbWFnZUJ1dHRvbjQFDEltYWdlQnV0dG9uNQUKSW1hS2FubmFkYY4o85F2dOP+gqZNLSyDQc72bLyN57+hyjxNCTOL0tdU" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<div class="aspNetHidden">

  <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="BCD81B8F" />
  <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAB3ywnS6IiuO+FCez9fnRELqAnreYlBWGSbWZ8PzZFVLGWLNV+2mZgnOAlNG5DVTg1vmrIx4Wzwbb1QZEjNCy6X4s+V9YTPCBDtGD4sSt9Nib13DazDmkpv+1rup7qinWaXW4H1AU2UapMn4+CE+FNJnr2mc5Bt6yMtxyRV/lyoHxz9YyyR4qjX0bKJ2X6bXV1Mvi1zv2zfvxmivUuslpagQqwThxiK0R3ZpqlwJgLvz6eYJKAPvp/8fDtxsMkj4WBm6f/9NVk/cD/N0P2pPUCLCbVD2Bs+oC+tVhisurIK4jIQxN4qwIfu78ABciZ/pEget6xb6ifsImJWFt5ut/PhJw+GtQvDhezJVVb+XXqASm4Pd4rpa/HsyBIhviniftdcrWSIgdvPCkMS8bYh6UKiofBKnF5XohMZP3byzFe1fR6+yCT9y/ysNwbc+94fxSn95WP7NuKNyRVSCk9bPAr39geQHZPPMsW7iHmlx7SKNA1/ASdfVR25GHQ93iHQLsE542e7jr8w4wgJzDQ3mXC0X7m/lYB9P3Nqym0ffAbWMc+G+YRyUzJ09lQhRVwS1eZARz6SBrTrFSCY8Bk9Anvfk10VNJvK2uiHUU8kn/A80wQB3rD1Y3n5TyZZwY4lrNMZtvJNh1wP27KJbHLxyKbkq" />
</div>
     <div style="height: auto;  padding-left: 300px;  padding-right: 300px;  width: 800px;text-align:center;">
            <table style="height: auto;   width: 760px;">
                    <tr>
                        <td>
                            <img id="Image1" src="Images/logo_ksphc_eng1.png" />
                        </td>
                       
                    </tr>
                    
                   
                </table>
                 <table   style="width: 100%;">
                     <tr style="background-color: #fff; height: 40px;">
                        <td style="color: #fff;text-align:center;">
                          
                            <table style="width:100%;">
                            <tr>
                                <td>
                                    <a href="index.html"><img src="Images/home.gif"></a>
                                    <!-- <input type="image" name="imgbtnHome" id="imgbtnHome" src="images/home.gif" /> -->
                                </td>
                                <td>
                                  <a href="projects.php"><img src="Images/projects.gif"></a>
                                    <!-- <input type="image" name="ImageButton4" id="ImageButton4" src="Images/projects.gif" /> -->

                                </td>
                                <td>
                                  <a href="innovation.html"><img src="Images/innovations.gif"></a>
                                    <!-- <input type="image" name="ImageButton5" id="ImageButton5" src="Images/innovations.gif" /> -->
                                </td>
                            </tr>
                        </table>
                        </td>
                         
                    </tr>
                      <tr style="background-color: #50bd1e; height: 40px;padding-top:0px;">
                        

                        <td align="right" style="color: #fff;width:100%;padding-left:20px;font-weight:bold;">             

                             <input type="image" name="ImaKannada" id="ImaKannada" src="Images/kannada.png" onclick="opennewtab();" style="height:20px;width:101px;" />
                           
                        </td>

                      
                    </tr>
                     
                </table>
               <table  style="width: 100%; height:auto;">
                     <tr style="background-color: #fff;">
                       <td style="width:10%; vertical-align:top;height:600px;">
                        
                            <table style="width:100%;">
                                <tr>
                                    <td style="text-align:center;height:30px;">

                                    <table style="width:99%; height: 25px;">
                                           
                                            <tr style="background-color:#f3751a;height:17px;">
                                                <td style="height:20px"; >
                                                    <br />

                                                  <input type="submit" name="Button2" value="Login To Youth Empowerment" onclick="opennewtabksphcmail();" id="Button2" style="font-weight:bold;height:17px;width:100%;" />
                                                   
                                                    <br />
                                                     <br />
                                                   
                                                </td>
                                            </tr>
                                        </table>
                                                                                                                    
                                       
                               
                                <tr>
                                   
                                    
                                </tr>
                               <tr style="background-color:#50bd1e;height:40px;text-align:center;font-weight:bold;">
                                   <td style="color:White">
                                       KSPH&IDCL.ORG
                                   </td>
                               </tr>
                               <tr>
                                   <td style="background-color:#d6f2a1;">
                                       <table style="width:100%;height:auto;">
                                           <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image2" src="Images/arrow.gif" /></td><td style="text-align:left;">
                                                   <a id="lnkhighligh" href="javascript:__doPostBack(&#39;lnkhighligh&#39;,&#39;&#39;)" style="text-decoration:none;">Highlights</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image3" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkfinance" href="javascript:__doPostBack(&#39;lnkfinance&#39;,&#39;&#39;)" style="text-decoration:none;">Financials</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image4" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkaccout" href="javascript:__doPostBack(&#39;lnkaccout&#39;,&#39;&#39;)" style="text-decoration:none;">Accountability</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image5" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkvisit" href="javascript:__doPostBack(&#39;lnkvisit&#39;,&#39;&#39;)" style="text-decoration:none;">Vision</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image6" src="Images/arrow.gif" /></td><td  style="text-align:left;"><a id="lnkmission" href="javascript:__doPostBack(&#39;lnkmission&#39;,&#39;&#39;)" style="text-decoration:none;">Mission</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image9" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkscheme" href="javascript:__doPostBack(&#39;lnkscheme&#39;,&#39;&#39;)" style="text-decoration:none;">Status Of Projects</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image7" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkawards" href="javascript:__doPostBack(&#39;lnkawards&#39;,&#39;&#39;)" style="text-decoration:none;">Awards</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image8" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkpolicy" href="javascript:__doPostBack(&#39;lnkpolicy&#39;,&#39;&#39;)" style="text-decoration:none;">Policies & Procedures</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image10" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkcomplaint" href="javascript:__doPostBack(&#39;lnkcomplaint&#39;,&#39;&#39;)" style="text-decoration:none;">Complaints</a></td>
                                           </tr>
                                            
                                           
                                           
                                           <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image13" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnktestimonials" href="javascript:__doPostBack(&#39;lnktestimonials&#39;,&#39;&#39;)" style="text-decoration:none;">Testimonials</a></td>
                                           </tr>
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image14" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkpolicedeptst" href="javascript:__doPostBack(&#39;lnkpolicedeptst&#39;,&#39;&#39;)" style="text-decoration:none;">Police Dpt websites Links</a></td>
                                           </tr>

                                           
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image17" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkRTI" href="javascript:__doPostBack(&#39;lnkRTI&#39;,&#39;&#39;)" style="text-decoration:none;">RTI</a></td>
                                           </tr>

                                           <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image18" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnknewcontr" href="javascript:__doPostBack(&#39;lnknewcontr&#39;,&#39;&#39;)" style="text-decoration:none;">Contractor Registeration</a></td>
                                           </tr>

                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image16" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkcontactus" href="javascript:__doPostBack(&#39;lnkcontactus&#39;,&#39;&#39;)" style="text-decoration:none;">Contact Us</a></td>
                                           </tr>
                                           
                                            <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image11" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkmeetng" href="javascript:__doPostBack(&#39;lnkmeetng&#39;,&#39;&#39;)" style="text-decoration:none;">Meetings and Proceedings</a></td>
                                           </tr>


                                           <tr>
                                               <td style="width:50px; text-align:center;"><img id="Image12" src="Images/arrow.gif" /></td><td style="text-align:left;"><a id="lnkcareer" href="javascript:__doPostBack(&#39;lnkcareer&#39;,&#39;&#39;)" style="text-decoration:none;">Careers</a></td>
                                           </tr>
                                       </table>
                                   </td>

                               </tr>
                                <tr  style="background-color:#f3751a;height:40px;text-align:center;font-weight:bold;">
                                    <td style="color:White" id="newsdesign">
                                        News
                                    </td>
                                </tr>
                                <tr>
                                    <td style="background-color:#efdcdc;">
                                        <marquee id="myMarquee" style="width:200px; height:575px" direction="up" onmouseover="this.stop();" onmouseout="this.start();">
                                         <table style="width:100%;">
                                          <tr>
                                               <td style="text-justify:auto;">
                                                   KSPH&IDCL has been awarded CIDC Vishwakarma Award 2017 for Achivement Award for Best Professionally Managed Company in Category III - Turnover INR 100-500 Crores. 
                                               </td>
                                           </tr>
                                           <tr>
                                                 <td style="text-align:right;"> <a id="lnkpdfturnover" href="javascript:__doPostBack(&#39;lnkpdfturnover&#39;,&#39;&#39;)"><font color=Red>Read More</font></a></td>
                                             </tr>
                                            <tr>
                                               <td style="text-justify:auto;">
                                               
                            KSPH&IDCL has been awarded CIDC Vishwakarma Award 2017 for Achivement Award for Best Construction Project for Fast Track Construction Technology for Mysore Project.                                          
                                               </td>
                                           </tr>
                                           <tr>
                                                 <td style="text-align:right;"> <a id="lnkpdfmysore" href="javascript:__doPostBack(&#39;lnkpdfmysore&#39;,&#39;&#39;)"><font color=Red>Read More</font></a></td>
                                             </tr>
                                           <tr>
                                               <td style="text-justify:auto;">
                                                   KSPH&IDCL has been awarded the 4th CIDC Vishwakarma Award 2012 under the category 'Achievement for Best Project' for 'Police Model Flats built in just 15 days' using EPS based pre-fab fast track construction technology.
                                               </td>
                                           </tr>
                                             <tr>
                                                 <td style="text-align:right;"> <a id="lnkpdf" href="javascript:__doPostBack(&#39;lnkpdf&#39;,&#39;&#39;)"><font color=Red>Read More</font></a></td>
                                             </tr>
                                             <tr>
                                                 <td style="text-justify:auto;">
                                                     KSPH&IDCL is certified to ISO 9001-2008 for its Quality Management System.
                                                 </td>
                                             </tr>
                                            <tr>
                                                 <td style="text-align:right;"> <a id="lnkksphcquality" href="javascript:__doPostBack(&#39;lnkksphcquality&#39;,&#39;&#39;)"><font color=Red>Read More</font></a></td>
                                             </tr>
                                             
                                           

                                          </table></marquee>
                                    </td>
                                </tr>
                               
                                 <tr>
                                    
                                </tr>
                               

                            </table>
                        </td>
                        <td id="maincontent" style="width:90%;vertical-align:top;">
                            <!--<iframe id="ifContent" style="border-style: none; border-color: inherit; border-width: medium; width:590px;height:1000px;" src="projects.aspx"></iframe>-->
                            <div class="kd" style= "width: 90%,height: 170vh,overflow: scroll">

                            
<div class="aspNetHidden">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwULLTE2MTY2ODcyMjlkZGTeYXaEeqJlh0+UhMFl6spj/SxGmQTzRNf4Il2+gQFq" />
</div>

<div class="aspNetHidden">

  <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="7065B718" />
</div>
    <div>
   <!-- new_products //-->
            <TABLE align="center" cellSpacing=0 cellPadding=0 border=0 width="512">
              <TBODY>
              <tr style="background-color:orange">
                <TD width="6"><IMG height=33 alt="" src="Images\m21.gif" 
                  width=6 border=0></TD>
                <TD class=bg2 width=494>&nbsp; &nbsp; &nbsp; <SPAN 
                  class=tx1><font size="3" face="Arial"><font>Projects</font>&nbsp;</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</SPAN></TD>
                <TD width="6"><IMG height=33 alt="" src="Images\m23.gif" 
                  width=6 border=0></TD>
              </tr>
              <tr>
                <TD class=bd 
                style="padding-left: 3px; padding-right: 3px; padding-top: 6px; padding-bottom: 3px" 
                width=504 colSpan=3>                  
                  <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
                    <TBODY>
                    <TR>
                      <TD>
<TABLE height=531 cellSpacing=0 cellPadding=0 border=0 width="502">
  <TBODY>
  <TR>
    <TD height="16" width="403"><object width="506" height="226" align="left" border="0">
<param name="movie" value="Images\projects.swf">
<embed src="Images\projects.swf" width="506" height="226"></object>  </TD></TR>
  <TR><!--<td width="31" height="3">&nbsp;</td>
    <td width="430" height="3"><IMG height=31 src="Heading%20pictures/Projects.gif" width=110></td>-->
    <TD width=403 height=15> </TD>
    <TD class=parab vAlign=top align=right width=95 rowSpan=3 height="515">&nbsp;<!--<a href="javascript:openwindow()"><font color=#cc0000>Site Visits</font></a>--></TD></TR>
     <TR>
    <TD class=para height="32" >
       
    <p align="left"><b><font face="Arial" size="2" color="#FF0000">Please click on the district on the map below to know the details of the projects</font></b></p>
     </TD></TR>
  <TR>
    <TD height="452" width="403">
      <P><IMG alt="District Map of Karnataka" 
      src="Images\final.jpg" 
      align=right useMap=#h3s1502 border=0 width="328" height="450"> <BR><BR><BR><MAP 
        name=h3s1502>
              <AREA shape=POLY alt="District of Bidar" 
        coords="223, 52, 214, 47, 209, 47, 207, 44, 198, 42, 195, 46, 186, 46, 181, 42, 185, 37, 185, 32, 193, 32, 193, 25, 193, 19, 203, 14, 209, 10, 211, 4, 218, 0, 222, 2, 221, 8, 231, 10, 233, 20, 230, 24, 238, 28, 228, 37, 231, 42, 226, 44" 
        href="districts.php?name=bidar">
              <AREA 
        shape=POLY alt="District of Udupi" 
        coords="47, 258, 42, 258, 45, 276, 51, 291, 51, 297, 53, 314, 73, 310, 75, 307, 73, 297, 73, 292, 70, 287, 68, 272, 60, 261" 
        href="districts.php?name=udupi">
              <AREA 
        shape=POLY alt="District of Hassan" 
        coords="150, 283, 155, 288, 149, 294, 154, 304, 167, 313, 168, 318, 159, 328, 150, 324, 152, 340, 144, 337, 137, 342, 126, 340, 126, 324, 119, 333, 108, 333, 101, 319, 114, 312, 116, 302, 129, 302, 129, 296, 145, 285, 143, 285, 154, 285, 154, 287" 
        href="districts.php?name=hassan">
              <AREA 
        shape=POLY alt="District of Mandya" 
        coords="147, 342, 148, 326, 159, 330, 167, 317, 174, 317, 184, 329, 192, 329, 197, 345, 202, 347, 207, 357, 196, 362, 188, 362, 183, 352, 172, 357, 167, 352, 161, 354" 
        href="districts.php?name=mandya">
        <AREA 
  shape=POLY alt="District of Bangalore Rural" 
  coords="218, 303, 218, 299, 213, 301, 213, 303, 212, 293, 218, 298, 209, 298, 214, 297, 212, 289, 218, 288, 232, 294, 231, 292, 246, 306, 241, 299, 246, 310, 246, 303, 243, 308, 244, 306, 248, 307, 245, 314, 248, 309, 248, 317, 244, 311, 246, 313, 243, 313, 244, 312, 246, 316, 245, 317, 244, 312, 241, 316, 238, 317, 233, 320, 229, 313, 224, 308, 226, 312, 216, 305, 215, 297, 219, 306, 221, 303, 217, 303, 215, 301, 215, 300, 214, 304"
  href="districts.php?name=bangalore" >
  <AREA 
  shape=POLY alt="District of Bangalore Urban" 
  coords="230, 344, 205, 350, 220, 348, 201, 353, 199, 348, 202, 353, 197, 350, 199, 344, 202, 338, 205, 333, 214, 330, 240, 323, 229, 346, 223, 349, 222, 349, 211, 349, 203, 351"
  href="districts.php?name=bangalore" >
  <AREA 
  shape=POLY alt="District of Bangalore Urban 2" 
  coords="200, 334, 228, 331, 229, 329, 199, 333, 231, 327, 225, 328, 230, 332, 226, 329, 230, 333, 231, 332, 225, 330, 226, 329, 227, 327, 223, 326, 228, 326, 231, 328, 231, 332, 229, 331, 216, 299, 229, 326, 230, 329, 226, 333, 228, 331, 225, 329, 227, 324, 228, 334, 219, 334, 229, 330, 227, 328, 223, 328, 228, 333, 230, 333, 227, 320, 220, 333, 232, 326, 223, 329, 229, 332, 230, 333, 224, 328, 226, 331, 230, 328, 231, 331, 216, 297, 196, 303"
  href="districts.php?name=bangalore" >
  <AREA 
  shape=POLY alt="District of Ramanagar" 
  coords="238, 372, 236, 370, 232, 377, 227, 378, 222, 378, 219, 375, 218, 369, 213, 363, 210, 364, 211, 358, 205, 356, 206, 349, 208, 348, 217, 348, 196"
  href="districts.php?name=ramanagar" >
        <AREA 
        shape=POLY alt="District of Bangalore" 
        coords=245,338,237,348,231,348,228,355,228,367,220,375,210,372,205,359,198,357,196,343,198,334,196,321,206,310,213,306,214,299,236,308,244,315,249,315 
        href="districts.php?name=bangalore">
        
        <AREA 
        shape=POLY alt="District of Kolar" 
        coords=216,289,237,284,244,273,251,274,251,278,260,278,260,289,265,294,277,294,275,305,286,315,281,328,281,335,273,335,267,344,258,338,253,341,245,337,246,325,250,317,243,315,239,308,217,300 
        href="districts.php?name=Kolar">

  <AREA 
  shape=POLY alt="District of Chikkaballapur" 
  coords="218, 274, 222, 273, 229, 271, 234, 274, 235, 269, 239, 266, 239, 262, 240, 262, 242, 262, 243, 264, 247, 262, 249, 262, 248, 264, 247, 267, 251, 266, 254, 265, 257, 267, 258, 270, 257, 275, 259, 279, 262, 282, 262, 287, 261, 291, 259, 294, 258, 296, 257, 297, 257, 300, 252, 300, 249, 300, 246, 299, 241, 298, 237, 299, 233, 296, 232"
  href="districts.php?name=chikkaballapur" > 
        <AREA 
        shape=POLY alt="District of Bagalkot" 
        coords="123, 147, 101, 146, 102, 130, 93, 126, 89, 120, 78, 114, 79, 111, 78, 103, 85, 96, 92, 98, 100, 88, 104, 109, 134, 115, 145, 128, 154, 143, 143, 143, 140, 138, 133, 142, 125, 137" 
        href="districts.php?name=bagalkot">
              <AREA 
        shape=POLY alt="District of Gadag" 
        coords="115, 199, 111, 198, 107, 191, 101, 191, 101, 177, 106, 171, 105, 169, 110, 161, 108, 154, 98, 156, 89, 154, 103, 145, 123, 146, 131, 146, 135, 151, 131, 151, 125, 163, 125, 169, 127, 185" 
        href="districts.php?name=gadag">
              <AREA 
        shape=POLY alt="District of Mysore" 
        coords="146, 392, 135, 385, 132, 379, 135, 371, 126, 359, 118, 353, 121, 344, 135, 344, 143, 341, 160, 353, 163, 353, 171, 358, 179, 354, 188, 361, 193, 364, 193, 368, 181, 368, 179, 376, 167, 376, 156, 382" 
        href="districts.php?name=mysore">
              <AREA 
        shape=POLY alt="District of Dakshin Kannad" 
        coords="52, 318, 54, 337, 63, 333, 68, 339, 78, 346, 86, 352, 90, 349, 95, 351, 102, 350, 105, 341, 98, 324, 93, 313, 86, 309, 76, 312" 
        href="districts.php?name=dakshin-kannad">
              <AREA 
        shape=POLY alt="District of Uttar Kannad" 
        coords="59, 172, 69, 180, 64, 186, 66, 193, 76, 193, 76, 203, 75, 217, 74, 222, 68, 225, 67, 230, 69, 239, 58, 245, 49, 247, 51, 257, 44, 260, 38, 235, 32, 218, 25, 213, 21, 202, 29, 199, 32, 190, 32, 179, 34, 177, 32, 165, 47, 175" 
        href="districts.php?name=uttarkannad">
        <AREA 
        shape=POLY alt="District of Gulbarga" 
        coords=179,48,174,40,161,51,159,61,162,68,155,63,149,67,142,66,146,75,152,76,159,75,163,91,163,104,161,107,161,119,156,123,153,128,161,131,175,125,193,115,209,123,217,119,223,116,223,109,225,104,223,98,227,89,225,85,220,79,226,69,236,59,224,55,215,49,208,49,197,45,192,47 
        href="districts.php?name=gulbarga">
         <AREA 
  shape=POLY alt="District of Yadgir" 
  
                  coords="162, 96, 168, 95, 171, 97, 179, 95, 184, 92, 188, 90, 193, 88, 196, 87, 203, 89, 209, 91, 214, 89, 218, 87, 223, 84, 223, 88, 224, 93, 223, 95, 223, 97, 221, 101, 223, 103, 224, 105, 221, 107, 219, 110, 216, 112, 215, 113, 211, 113, 209, 116, 204, 114, 199, 111, 197, 110, 194, 107, 189, 110, 184, 112, 180, 113, 174, 117, 169, 119, 163, 123, 157, 124, 155, 124, 153, 120, 156, 114, 160, 112, 160, 106, 159, 100, 161, 98, 162, 96" 
                  href="districts.php?name=yadgir">
        
        <AREA 
        shape=POLY alt="District of Davangere" 
        coords="124, 269, 137, 260, 134, 250, 142, 232, 156, 230, 164, 221, 146, 214, 139, 200, 125, 203, 117, 211, 117, 225, 109, 237, 103, 237, 99, 248, 118, 251" 
        href="districts.php?name=davangere">
              <AREA 
        shape=POLY alt="District of Shimoga" 
        coords="76, 288, 83, 280, 92, 280, 100, 269, 123, 267, 120, 249, 107, 251, 96, 248, 102, 239, 97, 232, 92, 221, 77, 216, 67, 222, 66, 238, 56, 241, 50, 242, 50, 255, 63, 257, 70, 273" 
        href="districts.php?name=shimoga">
              <AREA 
        shape=POLY alt="District of Bijapur" 
        coords="138, 56, 134, 56, 131, 50, 125, 53, 118, 46, 112, 50, 115, 62, 115, 75, 109, 78, 101, 76, 95, 78, 97, 87, 101, 89, 102, 107, 119, 112, 133, 114, 141, 127, 155, 121, 151, 115, 157, 110, 159, 96, 159, 79, 157, 66, 145, 65, 133, 55, 132, 50, 127, 54" 
        href="districts.php?name=bijapur">
              <AREA 
        shape=POLY alt="District of ChitraDurga" 
        coords="174, 197, 181, 200, 186, 205, 180, 216, 180, 223, 188, 232, 188, 238, 189, 246, 189, 253, 185, 256, 177, 265, 177, 271, 168, 273, 164, 280, 152, 286, 147, 286, 142, 278, 132, 265, 138, 263, 134, 254, 141, 235, 153, 234, 163, 224, 175, 213" 
        href="districts.php?name=chitradurga">
              <AREA 
        shape=POLY alt="District of Tumkur" 
        coords="217, 276, 212, 282, 213, 291, 210, 300, 205, 300, 193, 313, 197, 320, 197, 334, 185, 332, 178, 319, 168, 319, 155, 309, 150, 299, 154, 295, 150, 286, 165, 280, 166, 271, 177, 270, 177, 266, 185, 254, 195, 261, 191, 273, 203, 274, 203, 267, 215, 268" 
        href="districts.php?name=tumkur">
              <AREA 
        shape=POLY alt="District of Chikmagalur" 
        coords="77, 309, 86, 305, 95, 310, 100, 321, 112, 313, 112, 304, 128, 302, 128, 298, 146, 285, 151, 285, 131, 265, 123, 269, 99, 269, 91, 279, 81, 281, 76, 290" 
        href="districts.php?name=chikmagalur">
              <AREA 
        shape=POLY alt="District of Koppal" 
        coords="149, 143, 138, 143, 136, 137, 131, 142, 120, 137, 119, 142, 133, 150, 131, 155, 127, 152, 120, 164, 123, 170, 123, 186, 131, 186, 137, 182, 179, 167, 163, 152" 
        href="districts.php?name=koppal">
              <AREA 
        shape=POLY alt="District of Haveri" 
        coords="76, 219, 76, 197, 82, 189, 100, 190, 109, 195, 117, 203, 116, 213, 119, 218, 119, 225, 107, 241, 99, 236, 92, 225" 
        href="districts.php?name=haveri">
              <AREA 
        shape=POLY alt="District of Raichur" 
        coords="148, 133, 156, 144, 160, 146, 166, 155, 184, 167, 191, 154, 199, 148, 215, 144, 225, 147, 228, 137, 225, 126, 232, 126, 223, 120, 211, 114, 196, 107" 
        href="districts.php?name=raichur">
              <AREA 
        shape=POLY alt="District of Bellary" 
        coords="181, 168, 165, 174, 148, 179, 142, 180, 137, 185, 129, 185, 116, 198, 114, 214, 121, 212, 121, 204, 139, 201, 143, 207, 146, 214, 162, 221, 176, 208, 175, 195, 180, 192, 196, 198, 203, 191, 198, 178, 203, 174, 194, 168, 199, 161, 200, 147, 189, 150" 
        href="districts.php?name=bellary">
              <AREA 
        shape=POLY alt="District of Dharwad" 
        coords="79, 194, 70, 192, 68, 184, 74, 179, 60, 169, 71, 158, 89, 154, 109, 156, 112, 161, 107, 174, 105, 191, 99, 191, 98, 187, 94, 189, 85, 185" 
        href="districts.php?name=dharwad">
              <AREA 
        shape=POLY alt="District of Chamarajnagar" 
        coords="185, 370, 183, 373, 171, 374, 170, 379, 161, 380, 148, 383, 138, 394, 145, 399, 153, 406, 166, 406, 172, 397, 185, 397, 205, 396, 209, 386, 217, 385, 224, 380, 220, 371, 208, 369, 196, 363" 
        href="districts.php?name=chamarajnagar">
              <AREA 
        shape=POLY alt="District of Belgaum" 
        coords="100, 83, 104, 90, 98, 97, 81, 102, 81, 114, 95, 124, 104, 129, 105, 147, 98, 151, 81, 157, 70, 157, 63, 167, 56, 173, 47, 172, 36, 165, 32, 158, 27, 157, 34, 147, 42, 148, 42, 143, 48, 137, 42, 133, 50, 130, 50, 121, 42, 117, 42, 111, 38, 103, 53, 97, 56, 100, 63, 100, 63, 91, 74, 91, 78, 81, 86, 80, 95, 84" 
        href="districts.php?name=belgaum">
              <AREA 
        shape=POLY alt="District of Kodagu" 
        coords="90, 348, 97, 357, 103, 365, 114, 371, 120, 378, 133, 378, 138, 369, 129, 358, 122, 350, 128, 342, 128, 326, 123, 333, 111, 333, 108, 343, 98, 343" 
        href="districts.php?name=kodagu"></MAP><!-- End of Client Side Image Map information --></P>
      <P></P></TD></TR>
  <TR>
    <TD class=para height="16" width="403">
      <CENTER> 
      <p></p>
      </CENTER></TD></TR></TBODY></TABLE>
                      </TD></TR>
                    <tr>
                      <TD></TD>
                    </tr>
                    <TR>
                      <TD>
                        <TABLE cellSpacing=1 cellPadding=2 width="100%" 
border=0>
                          <TBODY>
                          <TR>
                            <TD>
                              <TABLE cellSpacing=0 cellPadding=2 width="100%" 
                              border=0>
                                <TBODY>
                                <TR>
                                <TD width=10><IMG height=1 alt="" 
                                src="Images\pixel_trans.gif" width=10 
                                border=0></TD>
                                <TD align=right></TD>
                                <TD width=10>
                                  <p align="center"><a href="#top"><img border="0" src="Images\arrow_top.gif" align="left" alt="Top"></a></p>
                                </TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE><!-- body_eof //--><!-- End code --></TD>
              </tr>
              <tr>
                <TD width="6"><IMG alt="" src="Images\m33.gif" border=0 width="6" height="6"></TD>
                <TD class=bg4 width=494></TD>
                <TD width="6"><IMG height=6 alt="" src="Images\m35.gif" 
                  width=6 
border=0></TD>
              </tr>
              </TBODY></TABLE>
          </TD></TR></TBODY>
          
          </TABLE>
         
                <table>
                    <tr>
          <td width="800" bgcolor="#c5c5c5" height="16">
            <p align="center">Copyright © 2021 | All Rights Reserved.
            &nbsp;&nbsp;</p></td>
        </tr>
                </table>
    </div>
    </form>
                        </td>
                    </tr>
                </table>

            </table>
        </div>
      </div>
    </form>
</body>
</html>


    <script type="text/javascript">

        function opennewtabksphcmail() {
            var path = "https://chillkrt.com/youth-emp/admin";
            window.open(path, '_blank')
        }
</script>
